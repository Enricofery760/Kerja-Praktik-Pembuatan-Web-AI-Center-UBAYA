import { describe, expect, test } from 'vitest';
import {
  kodeFilterQuery,
  pesertaIdSah,
  slugDariJudul,
  validasiBerita,
  validasiDokumentasi,
  validasiHero,
  validasiInference,
  validasiKursus,
  validasiLayanan,
  validasiProfil,
  validasiProgress,
  validasiTestimoni,
  validasiTim,
} from './tulis';

describe('slugDariJudul', () => {
  test('judul normal → slug lowercase dengan strip', () => {
    expect(slugDariJudul('Demo Inference Solution untuk Mitra')).toBe(
      'demo-inference-solution-untuk-mitra',
    );
  });

  test('tanda baca dibuang, spasi ganda/underscore jadi satu strip', () => {
    expect(slugDariJudul('  AI: Center — Ubaya!  ')).toBe('ai-center-ubaya');
    expect(slugDariJudul('angka 2026 &AI')).toBe('angka-2026-ai');
  });

  test('edge: input kosong / tanpa karakter sah → "" (route menolak dengan 400)', () => {
    expect(slugDariJudul('')).toBe('');
    expect(slugDariJudul('!!! ???')).toBe('');
  });
});

const BODY_DOK_VALID = {
  judul: 'Workshop GPU',
  deskripsi: 'Dokumentasi workshop.',
  tanggal: '2026-10-01',
  kategori: 'Workshop',
};

const BODY_BERITA_VALID = {
  judul: 'Berita Baru',
  ringkasan: 'Ringkasan singkat.',
  isi: 'Isi lengkap berita.',
  tanggal: '2026-10-01',
  penulis: 'Admin',
};

describe('validasiDokumentasi', () => {
  test('body lengkap → ok, gambar default null, teks di-trim', () => {
    const hasil = validasiDokumentasi({ ...BODY_DOK_VALID, judul: ' Workshop GPU ' });
    expect(hasil).toEqual({
      ok: true,
      data: { ...BODY_DOK_VALID, judul: 'Workshop GPU', gambar: null },
    });
  });

  test('field wajib kosong/hilang → error eksplisit menyebut field', () => {
    const tanpaJudul = validasiDokumentasi({ ...BODY_DOK_VALID, judul: '   ' });
    expect(tanpaJudul).toEqual({ ok: false, error: 'Field "judul" wajib diisi' });
    const { judul: _dibuang, ...tanpaJudul2 } = BODY_DOK_VALID;
    expect(validasiDokumentasi(tanpaJudul2)).toEqual({ ok: false, error: 'Field "judul" wajib diisi' });
  });

  test('tanggal bukan YYYY-MM-DD atau tidak ada di kalender → tolak', () => {
    expect(validasiDokumentasi({ ...BODY_DOK_VALID, tanggal: '01/10/2026' })).toEqual({
      ok: false,
      error: 'Field "tanggal" harus format YYYY-MM-DD',
    });
    // Lolos pola tapi tidak ada di kalender → cabang "tidak valid" yang kedua.
    expect(validasiDokumentasi({ ...BODY_DOK_VALID, tanggal: '2026-02-30' })).toEqual({
      ok: false,
      error: 'Field "tanggal" tidak valid: 2026-02-30',
    });
  });

  test('edge: body bukan objek → tolak', () => {
    expect(validasiDokumentasi(null)).toEqual({ ok: false, error: 'Body harus objek JSON' });
    expect(validasiDokumentasi('halo')).toEqual({ ok: false, error: 'Body harus objek JSON' });
  });

  test('gambar terisi string dipertahankan; tipe salah → tolak', () => {
    const denganGambar = validasiDokumentasi({ ...BODY_DOK_VALID, gambar: '/berita/x.jpg' });
    expect(denganGambar.ok).toBe(true);
    if (denganGambar.ok) expect(denganGambar.data.gambar).toBe('/berita/x.jpg');
    expect(validasiDokumentasi({ ...BODY_DOK_VALID, gambar: 123 })).toEqual({
      ok: false,
      error: 'Field "gambar" harus teks',
    });
  });
});

describe('validasiBerita', () => {
  test('body lengkap → ok, semua field terpetak', () => {
    const hasil = validasiBerita({ ...BODY_BERITA_VALID, gambar: '' });
    expect(hasil).toEqual({
      ok: true,
      data: { ...BODY_BERITA_VALID, gambar: null },
    });
  });

  test('field ringkasan/isi/penulis wajib — pesan menyebut field yang salah', () => {
    expect(validasiBerita({ ...BODY_BERITA_VALID, penulis: '' })).toEqual({
      ok: false,
      error: 'Field "penulis" wajib diisi',
    });
    const { isi: _isiDibuang, ...tanpaIsi } = BODY_BERITA_VALID;
    expect(validasiBerita(tanpaIsi)).toEqual({ ok: false, error: 'Field "isi" wajib diisi' });
  });
});

const BODY_KURSUS_VALID = {
  kode: 'r01',
  judul: 'Dasar Machine Learning',
  deskripsi: 'Deskripsi singkat.',
  tentang: 'Tentang panjang.',
  durasi: '4 sesi',
  level: 'Pemula',
  format: 'Online',
  instruktur: 'Budi',
  peran: 'Pengajar',
  inisial: 'B',
  target: ['Mahasiswa', ''],
  hasil: ['Mampu regresi'],
  modul: [{ judul: 'M1', deskripsi: 'D1', meta: '4 video' }],
};

describe('validasiKursus', () => {
  test('body valid → kode di-uppercase + array dibersihkan', () => {
    const hasil = validasiKursus(BODY_KURSUS_VALID);
    expect(hasil.ok).toBe(true);
    if (hasil.ok) {
      expect(hasil.data.kode).toBe('R01');
      expect(hasil.data.target).toEqual(['Mahasiswa']);
    }
  });

  test('kode pola salah / teks wajib kosong → error eksplisit', () => {
    expect(validasiKursus({ ...BODY_KURSUS_VALID, kode: 'r 01!' }).ok).toBe(false);
    expect(validasiKursus({ ...BODY_KURSUS_VALID, judul: '  ' })).toEqual({
      ok: false,
      error: 'Field "judul" wajib diisi',
    });
  });

  test('target/hasil harus array berisi; modul minimal 1 lengkap', () => {
    expect(validasiKursus({ ...BODY_KURSUS_VALID, target: [] }).ok).toBe(false);
    expect(validasiKursus({ ...BODY_KURSUS_VALID, hasil: 'teks' }).ok).toBe(false);
    expect(validasiKursus({ ...BODY_KURSUS_VALID, modul: [] })).toEqual({
      ok: false,
      error: 'Field "modul" minimal 1 modul',
    });
    expect(
      validasiKursus({ ...BODY_KURSUS_VALID, modul: [{ judul: 'M1', deskripsi: '', meta: 'x' }] }),
    ).toEqual({ ok: false, error: 'Modul ke-1: field "deskripsi" wajib diisi' });
  });

  test('batas panjang: judul >200, modul meta >200, target item >200 → tolak', () => {
    expect(validasiKursus({ ...BODY_KURSUS_VALID, judul: 'x'.repeat(201) })).toEqual({
      ok: false,
      error: 'Field "judul" maksimal 200 karakter',
    });
    expect(
      validasiKursus({
        ...BODY_KURSUS_VALID,
        modul: [{ judul: 'M1', deskripsi: 'D1', meta: 'x'.repeat(201) }],
      }),
    ).toEqual({ ok: false, error: 'Modul ke-1: field "meta" maksimal 200 karakter' });
    expect(
      validasiKursus({ ...BODY_KURSUS_VALID, target: ['x'.repeat(201)] }),
    ).toEqual({ ok: false, error: 'Field "target" maksimal 200 karakter per item' });
  });
});

// — Kursus: video & kuis per modul (sistem video/asesmen) ———————————————————————

const SOAL_VALID = {
  pertanyaan: 'Apa kata kunci yang baik untuk riset?',
  opsi: ['Kata kunci spesifik', 'Kata umum satu kata'],
  kunci: 0,
};
/** Body kursus dengan modul yang membawa `video`/`quiz` (untuk kasus per kasus). */
const kursusDenganModul = (modul: unknown) => ({
  ...BODY_KURSUS_VALID,
  modul,
});

describe('validasiKursus — video & kuis per modul', () => {
  test('video/quiz absen (body lama) → dinormalkan null / []', () => {
    const hasil = validasiKursus(BODY_KURSUS_VALID);
    expect(hasil.ok).toBe(true);
    if (hasil.ok) {
      expect(hasil.data.modul[0].video).toBeNull();
      expect(hasil.data.modul[0].quiz).toEqual([]);
    }
  });

  test('video valid http(s) → terpetak; bukan URL → tolak eksplisit', () => {
    const ok = validasiKursus(
      kursusDenganModul([
        { judul: 'M1', deskripsi: 'D1', meta: '4 video', video: 'https://youtu.be/abc123' },
      ]),
    );
    expect(ok.ok).toBe(true);
    if (ok.ok) expect(ok.data.modul[0].video).toBe('https://youtu.be/abc123');

    expect(
      validasiKursus(
        kursusDenganModul([{ judul: 'M1', deskripsi: 'D1', meta: 'x', video: 'bukan-url' }]),
      ),
    ).toEqual({ ok: false, error: 'Modul ke-1: field "video" harus URL http(s)' });
  });

  test('kuis valid → terpetak utuh (kunci = index opsi)', () => {
    const hasil = validasiKursus(
      kursusDenganModul([{ judul: 'M1', deskripsi: 'D1', meta: 'x', quiz: [SOAL_VALID] }]),
    );
    expect(hasil.ok).toBe(true);
    if (hasil.ok) expect(hasil.data.modul[0].quiz).toEqual([SOAL_VALID]);
  });

  test('kuis invalid: bukan array / opsi <2 / kunci di luar rentang / >10 soal → tolak', () => {
    expect(validasiKursus(kursusDenganModul([{ judul: 'M1', deskripsi: 'D1', meta: 'x', quiz: 'bukan-array' }]))).toEqual({
      ok: false,
      error: 'Modul ke-1: field "quiz" harus array',
    });
    expect(
      validasiKursus(
        kursusDenganModul([{ judul: 'M1', deskripsi: 'D1', meta: 'x', quiz: [{ pertanyaan: 'P?', opsi: ['satu'], kunci: 0 }] }]),
      ),
    ).toEqual({ ok: false, error: 'Modul ke-1, soal ke-1: "opsi" minimal 2' });
    expect(
      validasiKursus(
        kursusDenganModul([{ judul: 'M1', deskripsi: 'D1', meta: 'x', quiz: [{ pertanyaan: 'P?', opsi: ['a', 'b'], kunci: 5 }] }]),
      ),
    ).toEqual({ ok: false, error: 'Modul ke-1, soal ke-1: "kunci" harus index opsi yang valid (0-1)' });
    const banyak = Array.from({ length: 11 }, () => SOAL_VALID);
    expect(validasiKursus(kursusDenganModul([{ judul: 'M1', deskripsi: 'D1', meta: 'x', quiz: banyak }]))).toEqual({
      ok: false,
      error: 'Modul ke-1: field "quiz" maksimal 10 soal',
    });
  });

  test('soal dengan pertanyaan kosong → tolak menyebut nomor soalnya', () => {
    expect(
      validasiKursus(
        kursusDenganModul([
          { judul: 'M1', deskripsi: 'D1', meta: 'x', quiz: [{ pertanyaan: '  ', opsi: ['a', 'b'], kunci: 0 }] },
        ]),
      ),
    ).toEqual({ ok: false, error: 'Modul ke-1, soal ke-1: "pertanyaan" wajib diisi' });
  });
});

// — Prioritas 2: batas panjang field teks ————————————————————————————————

describe('batas panjang field teks (Prioritas 2)', () => {
  test('dokumentasi: deskripsi >10000 & kategori >100 → tolak dengan pesan field', () => {
    expect(validasiDokumentasi({ ...BODY_DOK_VALID, deskripsi: 'x'.repeat(10_001) })).toEqual({
      ok: false,
      error: 'Field "deskripsi" maksimal 10000 karakter',
    });
    expect(validasiDokumentasi({ ...BODY_DOK_VALID, kategori: 'x'.repeat(101) })).toEqual({
      ok: false,
      error: 'Field "kategori" maksimal 100 karakter',
    });
  });

  test('berita: judul 201 & ringkasan 501 → tolak; tepat batas lolos', () => {
    expect(validasiBerita({ ...BODY_BERITA_VALID, judul: 'x'.repeat(201) })).toEqual({
      ok: false,
      error: 'Field "judul" maksimal 200 karakter',
    });
    expect(validasiBerita({ ...BODY_BERITA_VALID, ringkasan: 'x'.repeat(501) })).toEqual({
      ok: false,
      error: 'Field "ringkasan" maksimal 500 karakter',
    });
    expect(validasiBerita({ ...BODY_BERITA_VALID, judul: 'x'.repeat(200) }).ok).toBe(true);
  });

  test('isi >20000 & gambar URL >500 → tolak', () => {
    expect(validasiBerita({ ...BODY_BERITA_VALID, isi: 'x'.repeat(20_001) })).toEqual({
      ok: false,
      error: 'Field "isi" maksimal 20000 karakter',
    });
    expect(
      validasiBerita({ ...BODY_BERITA_VALID, gambar: `/${'x'.repeat(501)}` }),
    ).toEqual({ ok: false, error: 'Field "gambar" maksimal 500 karakter' });
  });
});

// — Prioritas 2: CRUD profil & tim ———————————————————————————————————————

const BODY_PROFIL_VALID = {
  nama: 'AI Center Universitas Surabaya',
  tagline: 'Pusat riset AI Ubaya.',
  ringkasan: 'Ringkasan profil.',
  alamat: 'Gedung Perpustakaan LT.4',
  email: 'aicenter@unit.ubaya.ac.id',
  telepon: '0895-6342-22240',
  visi: 'Menjadi yang terdepan — Deskripsi visi.',
  misi: 'Mendorong riset.\nMenghasilkan produk.',
};

describe('validasiProfil', () => {
  test('body lengkap → ok, semua field terpetak, teks di-trim', () => {
    const hasil = validasiProfil({ ...BODY_PROFIL_VALID, nama: '  AI Center  ' });
    expect(hasil).toEqual({ ok: true, data: { ...BODY_PROFIL_VALID, nama: 'AI Center' } });
  });

  test('visi/misi kosong → null (DB NULL, frontend pakai fallback)', () => {
    const hasil = validasiProfil({ ...BODY_PROFIL_VALID, visi: '   ', misi: '' });
    expect(hasil.ok).toBe(true);
    if (hasil.ok) {
      expect(hasil.data.visi).toBeNull();
      expect(hasil.data.misi).toBeNull();
    }
  });

  test('field wajib hilang/kosong → error menyebut field', () => {
    expect(validasiProfil({ ...BODY_PROFIL_VALID, alamat: '' })).toEqual({
      ok: false,
      error: 'Field "alamat" wajib diisi',
    });
    const { email: _dibuang, ...tanpaEmail } = BODY_PROFIL_VALID;
    expect(validasiProfil(tanpaEmail)).toEqual({ ok: false, error: 'Field "email" wajib diisi' });
  });

  test('batas panjang: nama >200, telepon >50, misi >10000 → tolak', () => {
    expect(validasiProfil({ ...BODY_PROFIL_VALID, nama: 'x'.repeat(201) })).toEqual({
      ok: false,
      error: 'Field "nama" maksimal 200 karakter',
    });
    expect(validasiProfil({ ...BODY_PROFIL_VALID, telepon: 'x'.repeat(51) })).toEqual({
      ok: false,
      error: 'Field "telepon" maksimal 50 karakter',
    });
    expect(validasiProfil({ ...BODY_PROFIL_VALID, misi: 'x'.repeat(10_001) })).toEqual({
      ok: false,
      error: 'Field "misi" maksimal 10000 karakter',
    });
  });

  test('edge: body bukan objek → tolak', () => {
    expect(validasiProfil(null)).toEqual({ ok: false, error: 'Body harus objek JSON' });
    expect(validasiProfil('bukan-objek')).toEqual({ ok: false, error: 'Body harus objek JSON' });
  });
});

const BODY_TIM_VALID = {
  nama: 'Dr. Contoh',
  peran: 'Ketua',
  kredensial: 'Ph.D.',
  foto: '/uploads/1712-contoh.jpg',
  urutan: 0,
};

describe('validasiTim', () => {
  test('body lengkap → ok, semua field terpetak', () => {
    expect(validasiTim(BODY_TIM_VALID)).toEqual({ ok: true, data: BODY_TIM_VALID });
  });

  test('kredensial/foto kosong → null (kolom opsional)', () => {
    const hasil = validasiTim({ ...BODY_TIM_VALID, kredensial: '', foto: undefined });
    expect(hasil.ok).toBe(true);
    if (hasil.ok) {
      expect(hasil.data.kredensial).toBeNull();
      expect(hasil.data.foto).toBeNull();
    }
  });

  test('nama/peran wajib → error menyebut field', () => {
    expect(validasiTim({ ...BODY_TIM_VALID, nama: '  ' })).toEqual({
      ok: false,
      error: 'Field "nama" wajib diisi',
    });
    expect(validasiTim({ ...BODY_TIM_VALID, peran: undefined })).toEqual({
      ok: false,
      error: 'Field "peran" wajib diisi',
    });
  });

  test('urutan bukan bilangan bulat valid → tolak eksplisit', () => {
    expect(validasiTim({ ...BODY_TIM_VALID, urutan: '1' })).toEqual({
      ok: false,
      error: 'Field "urutan" harus bilangan bulat 0-9999',
    });
    expect(validasiTim({ ...BODY_TIM_VALID, urutan: 1.5 })).toEqual({
      ok: false,
      error: 'Field "urutan" harus bilangan bulat 0-9999',
    });
    expect(validasiTim({ ...BODY_TIM_VALID, urutan: -1 })).toEqual({
      ok: false,
      error: 'Field "urutan" harus bilangan bulat 0-9999',
    });
  });

  test('batas panjang: nama >200, kredensial >300 → tolak', () => {
    expect(validasiTim({ ...BODY_TIM_VALID, nama: 'x'.repeat(201) })).toEqual({
      ok: false,
      error: 'Field "nama" maksimal 200 karakter',
    });
    expect(validasiTim({ ...BODY_TIM_VALID, kredensial: 'x'.repeat(301) })).toEqual({
      ok: false,
      error: 'Field "kredensial" maksimal 300 karakter',
    });
  });
});

// — Konten halaman inference (GET/PUT /api/inference) ———————————————————

const BODY_INFERENCE_VALID = {
  judulApaItu: 'Apa itu Inference Solution?',
  deskripsiApaItu: 'Inference adalah tahap menjalankan model machine learning.',
  kebutuhan: ['Model belum dipakai tim lain', 'Butuh fitur AI di aplikasi'],
  alur: [
    { nomor: '01', judul: 'Konsultasi', deskripsi: 'Memetakan use case.' },
    { nomor: '02', judul: 'Deployment', deskripsi: 'Menjalankan model sebagai API.' },
  ],
  contohIntro: 'Beberapa produk AI Center:',
  contoh: [{ slug: 'algae-finder', judul: 'Algae Finder' }],
};

describe('validasiInference', () => {
  test('body lengkap → ok, semua field terpetak', () => {
    expect(validasiInference(BODY_INFERENCE_VALID)).toEqual({
      ok: true,
      data: BODY_INFERENCE_VALID,
    });
  });

  test('teks di-trim & item daftar kosong dibuang', () => {
    const hasil = validasiInference({
      ...BODY_INFERENCE_VALID,
      judulApaItu: '  Apa itu Inference Solution?  ',
      kebutuhan: ['  Model belum dipakai tim lain  ', 'Butuh fitur AI di aplikasi', '   '],
    });
    expect(hasil.ok).toBe(true);
    if (hasil.ok) {
      expect(hasil.data.judulApaItu).toBe('Apa itu Inference Solution?');
      expect(hasil.data.kebutuhan).toEqual([
        'Model belum dipakai tim lain',
        'Butuh fitur AI di aplikasi',
      ]);
    }
  });

  test('field wajib kosong / hilang → error menyebut field', () => {
    expect(validasiInference({ ...BODY_INFERENCE_VALID, contohIntro: '' })).toEqual({
      ok: false,
      error: 'Field "contohIntro" wajib diisi',
    });
    const { alur: _dibuang, ...tanpaAlur } = BODY_INFERENCE_VALID;
    expect(validasiInference(tanpaAlur)).toEqual({
      ok: false,
      error: 'Field "alur" harus array objek',
    });
  });

  test('daftar kosong → tolak minimal 1 item', () => {
    expect(validasiInference({ ...BODY_INFERENCE_VALID, kebutuhan: [] })).toEqual({
      ok: false,
      error: 'Field "kebutuhan" minimal 1 item',
    });
    expect(validasiInference({ ...BODY_INFERENCE_VALID, contoh: [] })).toEqual({
      ok: false,
      error: 'Field "contoh" minimal 1 item',
    });
  });

  test('item daftar bukan objek → tolak eksplisit', () => {
    expect(validasiInference({ ...BODY_INFERENCE_VALID, alur: ['bukan objek'] })).toEqual({
      ok: false,
      error: 'Item "alur" ke-1 tidak valid',
    });
  });

  test('field di dalam langkah/contoh wajib & berbatas → tolak menyebut langkah', () => {
    expect(
      validasiInference({
        ...BODY_INFERENCE_VALID,
        alur: [{ nomor: '01', judul: '  ', deskripsi: 'Memetakan use case.' }],
      }),
    ).toEqual({ ok: false, error: 'Langkah ke-1: field "judul" wajib diisi' });
    expect(
      validasiInference({
        ...BODY_INFERENCE_VALID,
        alur: [{ nomor: '01', judul: 'Konsultasi', deskripsi: 'x'.repeat(1_001) }],
      }),
    ).toEqual({ ok: false, error: 'Langkah ke-1: field "deskripsi" maksimal 1000 karakter' });
    expect(
      validasiInference({
        ...BODY_INFERENCE_VALID,
        contoh: [{ slug: 'x'.repeat(201), judul: 'Algae Finder' }],
      }),
    ).toEqual({ ok: false, error: 'Contoh ke-1: field "slug" maksimal 200 karakter' });
  });

  test('batas panjang: judul >200, deskripsi >5000, kebutuhan item >300 → tolak', () => {
    expect(validasiInference({ ...BODY_INFERENCE_VALID, judulApaItu: 'x'.repeat(201) })).toEqual({
      ok: false,
      error: 'Field "judulApaItu" maksimal 200 karakter',
    });
    expect(
      validasiInference({ ...BODY_INFERENCE_VALID, deskripsiApaItu: 'x'.repeat(5_001) }),
    ).toEqual({ ok: false, error: 'Field "deskripsiApaItu" maksimal 5000 karakter' });
    expect(
      validasiInference({ ...BODY_INFERENCE_VALID, kebutuhan: ['x'.repeat(301)] }),
    ).toEqual({ ok: false, error: 'Field "kebutuhan" maksimal 300 karakter per item' });
  });

  test('edge: body bukan objek → tolak', () => {
    expect(validasiInference(null)).toEqual({ ok: false, error: 'Body harus objek JSON' });
  });
});

// — Lengkapi CRUD admin: testimoni & slide hero ————————————————————————

const BODY_TESTIMONI_VALID = {
  nama: 'Peserta Pelatihan ML',
  peran: 'Mahasiswa',
  kutipan: 'Materi pelatihan runtut dan langsung praktik.',
  urutan: 0,
};

describe('validasiTestimoni', () => {
  test('body lengkap → ok, semua field terpetak', () => {
    expect(validasiTestimoni(BODY_TESTIMONI_VALID)).toEqual({
      ok: true,
      data: BODY_TESTIMONI_VALID,
    });
  });

  test('field wajib kosong → error menyebut field', () => {
    expect(validasiTestimoni({ ...BODY_TESTIMONI_VALID, nama: '   ' })).toEqual({
      ok: false,
      error: 'Field "nama" wajib diisi',
    });
    expect(validasiTestimoni({ ...BODY_TESTIMONI_VALID, kutipan: undefined })).toEqual({
      ok: false,
      error: 'Field "kutipan" wajib diisi',
    });
    expect(validasiTestimoni({ ...BODY_TESTIMONI_VALID, peran: 123 })).toEqual({
      ok: false,
      error: 'Field "peran" wajib diisi',
    });
  });

  test('batas panjang: nama >200, peran >200, kutipan >1000 → tolak', () => {
    expect(validasiTestimoni({ ...BODY_TESTIMONI_VALID, nama: 'x'.repeat(201) })).toEqual({
      ok: false,
      error: 'Field "nama" maksimal 200 karakter',
    });
    expect(validasiTestimoni({ ...BODY_TESTIMONI_VALID, peran: 'x'.repeat(201) })).toEqual({
      ok: false,
      error: 'Field "peran" maksimal 200 karakter',
    });
    expect(validasiTestimoni({ ...BODY_TESTIMONI_VALID, kutipan: 'x'.repeat(1_001) })).toEqual({
      ok: false,
      error: 'Field "kutipan" maksimal 1000 karakter',
    });
  });

  test('urutan tidak valid & body bukan objek → tolak eksplisit', () => {
    expect(validasiTestimoni({ ...BODY_TESTIMONI_VALID, urutan: '3' })).toEqual({
      ok: false,
      error: 'Field "urutan" harus bilangan bulat 0-9999',
    });
    expect(validasiTestimoni({ ...BODY_TESTIMONI_VALID, urutan: -1 })).toEqual({
      ok: false,
      error: 'Field "urutan" harus bilangan bulat 0-9999',
    });
    expect(validasiTestimoni('bukan-objek')).toEqual({
      ok: false,
      error: 'Body harus objek JSON',
    });
  });
});

const BODY_LAYANAN_VALID = {
  nama: 'Pelatihan AI',
  tagline: 'Pelatihan AI yang benar-benar dipakai sehari-hari.',
  deskripsi: 'Ubaya AI Center mendampingi belajar AI dari dasar sampai penerapan.',
  fitur: ['Workshop terjadwal', 'Pendampingan'],
};

describe('validasiLayanan', () => {
  test('body lengkap → ok, semua field terpetak (fitur utuh)', () => {
    expect(validasiLayanan(BODY_LAYANAN_VALID)).toEqual({
      ok: true,
      data: BODY_LAYANAN_VALID,
    });
  });

  test('field wajib kosong → error menyebut field', () => {
    expect(validasiLayanan({ ...BODY_LAYANAN_VALID, nama: '  ' })).toEqual({
      ok: false,
      error: 'Field "nama" wajib diisi',
    });
    expect(validasiLayanan({ ...BODY_LAYANAN_VALID, tagline: undefined })).toEqual({
      ok: false,
      error: 'Field "tagline" wajib diisi',
    });
    expect(validasiLayanan({ ...BODY_LAYANAN_VALID, deskripsi: 123 })).toEqual({
      ok: false,
      error: 'Field "deskripsi" wajib diisi',
    });
  });

  test('batas panjang: nama >150, tagline >300, deskripsi >2000 → tolak', () => {
    expect(validasiLayanan({ ...BODY_LAYANAN_VALID, nama: 'x'.repeat(151) })).toEqual({
      ok: false,
      error: 'Field "nama" maksimal 150 karakter',
    });
    expect(validasiLayanan({ ...BODY_LAYANAN_VALID, tagline: 'x'.repeat(301) })).toEqual({
      ok: false,
      error: 'Field "tagline" maksimal 300 karakter',
    });
    expect(validasiLayanan({ ...BODY_LAYANAN_VALID, deskripsi: 'x'.repeat(2_001) })).toEqual({
      ok: false,
      error: 'Field "deskripsi" maksimal 2000 karakter',
    });
  });

  test('fitur: bukan array / kosong / >15 item / item >300 → tolak eksplisit', () => {
    expect(validasiLayanan({ ...BODY_LAYANAN_VALID, fitur: 'bukan-array' })).toEqual({
      ok: false,
      error: 'Field "fitur" harus array teks',
    });
    expect(validasiLayanan({ ...BODY_LAYANAN_VALID, fitur: [] })).toEqual({
      ok: false,
      error: 'Field "fitur" minimal 1 item',
    });
    expect(
      validasiLayanan({ ...BODY_LAYANAN_VALID, fitur: Array.from({ length: 16 }, (_, i) => `f${i}`) }),
    ).toEqual({ ok: false, error: 'Field "fitur" maksimal 15 item' });
    expect(validasiLayanan({ ...BODY_LAYANAN_VALID, fitur: ['x'.repeat(301)] })).toEqual({
      ok: false,
      error: 'Field "fitur" maksimal 300 karakter per item',
    });
  });

  test('body bukan objek → tolak eksplisit', () => {
    expect(validasiLayanan('bukan-objek')).toEqual({
      ok: false,
      error: 'Body harus objek JSON',
    });
  });
});

const BODY_HERO_VALID = {
  urutan: 0,
  eyebrow: 'AI Center Ubaya',
  judul: 'Kami membangun solusi AI',
  judulAksen: 'untuk industri & akademik',
  sub: 'Riset, pelatihan, dan inference solution dalam satu pintu.',
  ctaPrimer: { label: 'Konsultasi Gratis', to: 'https://wa.me/6289563422240' },
  ctaSekunder: { label: 'Layanan Kami', to: '/layanan' },
  badgeJudul: 'AI Center',
  badgeSub: 'Universitas Surabaya',
  image: '/hero/ai-center.jpg',
  srcSet: '/hero/ai-center-800.webp 800w, /hero/ai-center-1600.webp 1600w',
  sizes: '(max-width: 768px) 100vw, 50vw',
  layout: 'default' as const,
};

describe('validasiHero', () => {
  test('body lengkap → ok, semua field terpetak', () => {
    expect(validasiHero(BODY_HERO_VALID)).toEqual({ ok: true, data: BODY_HERO_VALID });
  });

  test('image/srcSet/sizes/layout kosong → null (kolom opsional)', () => {
    const hasil = validasiHero({
      ...BODY_HERO_VALID,
      image: '',
      srcSet: undefined,
      sizes: '   ',
      layout: '',
    });
    expect(hasil.ok).toBe(true);
    if (hasil.ok) {
      expect(hasil.data.image).toBeNull();
      expect(hasil.data.srcSet).toBeNull();
      expect(hasil.data.sizes).toBeNull();
      expect(hasil.data.layout).toBeNull();
    }
  });

  test('layout di luar enum → tolak dengan daftar nilai sah', () => {
    expect(validasiHero({ ...BODY_HERO_VALID, layout: 'tengah' })).toEqual({
      ok: false,
      error: 'Field "layout" harus salah satu dari: default, image-left, teks-kanan',
    });
    expect(validasiHero({ ...BODY_HERO_VALID, layout: 42 })).toEqual({
      ok: false,
      error: 'Field "layout" harus salah satu dari: default, image-left, teks-kanan',
    });
  });

  test('CTA bukan objek / label kosong → tolak menyebut nama fieldnya', () => {
    expect(validasiHero({ ...BODY_HERO_VALID, ctaPrimer: null })).toEqual({
      ok: false,
      error: 'Field "ctaPrimer" harus objek { label, to }',
    });
    expect(
      validasiHero({ ...BODY_HERO_VALID, ctaSekunder: { label: '  ', to: '/x' } }),
    ).toEqual({ ok: false, error: 'Field "ctaSekunder.label" wajib diisi' });
    expect(
      validasiHero({ ...BODY_HERO_VALID, ctaPrimer: { label: 'Mulai', to: '' } }),
    ).toEqual({ ok: false, error: 'Field "ctaPrimer.to" wajib diisi' });
  });

  test('batas panjang: judul >150, sub >400, badgeSub >200, label CTA >150 → tolak', () => {
    expect(validasiHero({ ...BODY_HERO_VALID, judul: 'x'.repeat(151) })).toEqual({
      ok: false,
      error: 'Field "judul" maksimal 150 karakter',
    });
    expect(validasiHero({ ...BODY_HERO_VALID, sub: 'x'.repeat(401) })).toEqual({
      ok: false,
      error: 'Field "sub" maksimal 400 karakter',
    });
    expect(validasiHero({ ...BODY_HERO_VALID, badgeSub: 'x'.repeat(201) })).toEqual({
      ok: false,
      error: 'Field "badgeSub" maksimal 200 karakter',
    });
    expect(
      validasiHero({
        ...BODY_HERO_VALID,
        ctaPrimer: { label: 'x'.repeat(151), to: '/layanan' },
      }),
    ).toEqual({ ok: false, error: 'Field "ctaPrimer.label" maksimal 150 karakter' });
    expect(validasiHero({ ...BODY_HERO_VALID, image: 'x'.repeat(501) })).toEqual({
      ok: false,
      error: 'Field "image" maksimal 500 karakter',
    });
  });

  test('urutan tidak valid & body bukan objek → tolak eksplisit', () => {
    expect(validasiHero({ ...BODY_HERO_VALID, urutan: 1.5 })).toEqual({
      ok: false,
      error: 'Field "urutan" harus bilangan bulat 0-9999',
    });
    expect(validasiHero(null)).toEqual({ ok: false, error: 'Body harus objek JSON' });
  });
});

// — Progres belajar peserta (GET/POST /api/progress, tanpa akun) ——————————

describe('pesertaIdSah & kodeFilterQuery (query progres)', () => {
  test('pesertaId: pola 8-64 [A-Za-z0-9-] → nilai bersih; selain itu → null', () => {
    expect(pesertaIdSah('abc12345-uuid')).toBe('abc12345-uuid');
    expect(pesertaIdSah('0123456789abcdef')).toBe('0123456789abcdef');
    expect(pesertaIdSah('abc')).toBeNull(); // terlalu pendek
    expect(pesertaIdSah('a'.repeat(65))).toBeNull(); // terlalu panjang
    expect(pesertaIdSah('id dengan spasi')).toBeNull();
    expect(pesertaIdSah('id!spesial')).toBeNull();
    expect(pesertaIdSah(undefined)).toBeNull();
    expect(pesertaIdSah(12345)).toBeNull();
  });

  test('kodeFilterQuery: kosong → null (tanpa filter); sah → uppercase; salah → error', () => {
    expect(kodeFilterQuery(undefined)).toEqual({ kode: null });
    expect(kodeFilterQuery('')).toEqual({ kode: null });
    expect(kodeFilterQuery('r01')).toEqual({ kode: 'R01' });
    expect(kodeFilterQuery('FTB-01')).toEqual({ kode: 'FTB-01' });
    expect(kodeFilterQuery('R01;DROP')).toEqual({
      error: 'Query "kode" hanya huruf/angka/- (maks 12)',
    });
    expect(kodeFilterQuery('x'.repeat(13))).toEqual({
      error: 'Query "kode" hanya huruf/angka/- (maks 12)',
    });
    expect(kodeFilterQuery(42)).toEqual({
      error: 'Query "kode" hanya huruf/angka/- (maks 12)',
    });
  });
});

describe('validasiProgress', () => {
  const BODY_PROGRESS_VALID = {
    pesertaId: 'abc12345-uuid',
    kode: 'r01',
    state: { enrolled: true, completed: [true, false], activeModule: 1 },
  };

  test('valid → kode ternormalisasi UPPERCASE, state lolos apa adanya', () => {
    const hasil = validasiProgress(BODY_PROGRESS_VALID);
    expect(hasil).toEqual({
      ok: true,
      data: {
        pesertaId: 'abc12345-uuid',
        kode: 'R01',
        state: BODY_PROGRESS_VALID.state,
      },
    });
  });

  test('body bukan objek / pesertaId tidak sah → tolak eksplisit', () => {
    expect(validasiProgress(null)).toEqual({ ok: false, error: 'Body harus objek JSON' });
    expect(validasiProgress('string')).toEqual({ ok: false, error: 'Body harus objek JSON' });
    expect(validasiProgress({ ...BODY_PROGRESS_VALID, pesertaId: 'abc' })).toEqual({
      ok: false,
      error: 'Field "pesertaId" harus 8-64 karakter (huruf/angka/-)',
    });
    expect(validasiProgress({ ...BODY_PROGRESS_VALID, pesertaId: undefined })).toEqual({
      ok: false,
      error: 'Field "pesertaId" harus 8-64 karakter (huruf/angka/-)',
    });
  });

  test('kode salah pola → tolak', () => {
    expect(validasiProgress({ ...BODY_PROGRESS_VALID, kode: 'R01;DROP' })).toEqual({
      ok: false,
      error: 'Field "kode" hanya huruf/angka/- (maks 12)',
    });
    expect(validasiProgress({ ...BODY_PROGRESS_VALID, kode: 42 })).toEqual({
      ok: false,
      error: 'Field "kode" hanya huruf/angka/- (maks 12)',
    });
  });

  test('state bukan objek (null/array/primitif) → tolak', () => {
    expect(validasiProgress({ ...BODY_PROGRESS_VALID, state: null })).toEqual({
      ok: false,
      error: 'Field "state" harus objek JSON',
    });
    expect(validasiProgress({ ...BODY_PROGRESS_VALID, state: [true] })).toEqual({
      ok: false,
      error: 'Field "state" harus objek JSON',
    });
    expect(validasiProgress({ ...BODY_PROGRESS_VALID, state: 'kacau' })).toEqual({
      ok: false,
      error: 'Field "state" harus objek JSON',
    });
  });

  test('state > 32KB → tolak (batas byte mencegah body raksasa masuk DB)', () => {
    const hasil = validasiProgress({
      ...BODY_PROGRESS_VALID,
      state: { review: 'x'.repeat(40_000) },
    });
    expect(hasil).toEqual({
      ok: false,
      error: 'Field "state" maksimal 32768 byte',
    });
    // Persis di batas masih lolos.
    const pasBatas = validasiProgress({
      ...BODY_PROGRESS_VALID,
      state: { review: 'x'.repeat(32_000) },
    });
    expect(pasBatas.ok).toBe(true);
  });
});
