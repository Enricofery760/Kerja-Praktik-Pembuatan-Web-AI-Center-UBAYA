/**
 * Dashboard admin: login sederhana (1 akun) + CRUD dokumentasi, berita, kursus,
 * tim & testimoni (5 tab). Konten halaman lain tidak lewat backend — diedit
 * langsung di file frontend: hero (src/data/hero.ts), profil (src/data/profil.ts),
 * inference (src/data/inference.ts) & layanan (src/data/layanan.ts).
 *
 * - UI sengaja bahasa Indonesia tanpa i18n — alat internal, bukan halaman publik.
 * - Token hasil POST /api/admin/login disimpan di localStorage; semua aksi tulis
 *   membawa Authorization: Bearer; status 401 → otomatis keluar (token kedaluwarsa).
 * - Gambar berupa FILE (bukan URL): dipilih lewat input file, diunggah ke
 *   POST /api/admin/upload saat Simpan, URL hasilnya disimpan di kolom `gambar`.
 * - Read memakai ambilDaftar (fallback [] bila backend mati), write memakai
 *   kirimJsonAdmin/kirimFileAdmin yang MELEMPAR ErrorApi — kegagalan wajib tampil.
 * - Slug dibuat server dari judul; saat edit slug dipegang tetap supaya tautan lama hidup.
 *   Kursus memakai `kode` sebagai kunci: dibuat otomatis saat tambah (lihat
 *   lib/kodeKursus) lalu tidak boleh diganti saat edit.
 * - Batas panjang field (atribut `maks` → maxLength) disejajarkan dengan
 *   server/src/lib/tulis.ts — server tetap penegak utamanya (400 eksplisit).
 * - Kategori dokumentasi memakai DROPDOWN opsi umum + "Lainnya (ketik sendiri)"
 *   (lihat OPSI_KATEGORI) — mencegah kategori bebas menumpuk & ambigu; nilai
 *   custom tetap diterima (server hanya membatasi 100 karakter).
 * - Tombol "Bersihkan gambar tidak terpakai" memanggil POST
 *   /api/admin/uploads/bersihkan (Prioritas 2) — menghapus file unggahan yang
 *   tidak dirujuk konten manapun.
 * - Kode kursus dibuat OTOMATIS dari target peserta (prefiks M/D/G/U + nomor
 *   berikutnya, lihat lib/kodeKursus) dan tidak bisa diketik; target peserta
 *   kini dropdown 1 pilihan dari 4 label filter katalog (bukan teks bebas).
 * - Tim & testimoni: form TAMBAH tidak menampilkan field urutan — item baru
 *   otomatis jadi paling atas (server menggeser baris lama +1, tidak ada yang
 *   dihapus); field urutan tetap ada saat Ubah untuk penataan manual.
 */
import { useEffect, useState, type ChangeEvent, type FormEvent, type ReactNode } from 'react';
import { ambilDaftar, kirimFileAdmin, kirimJsonAdmin } from '../lib/api.ts';
import { LABEL_PESERTA, kodeOtomatis } from '../lib/kodeKursus.ts';
import type { BeritaItem } from '../data/berita.ts';
import type { DokumentasiItem } from '../data/dokumentasi.ts';
import type { Kursus, Modul, Soal } from '../data/pelatihan.ts';
import type { Testimoni } from '../data/testimoni.ts';
import type { AnggotaTim } from '../data/tim.ts';

/** Kunci localStorage untuk token sesi admin. */
export const KEY_TOKEN_ADMIN = 'token-admin';

type Jenis = 'dokumentasi' | 'berita' | 'kursus' | 'tim' | 'testimoni';
/** Jenis yang memakai alur daftar+form generik di komponen utama (kursus/tim/
    testimoni punya komponen admin sendiri karena bentuk datanya beda). */
type JenisDaftar = 'dokumentasi' | 'berita';
type ItemAdmin = DokumentasiItem | BeritaItem;

interface FieldDef {
  kunci: string;
  label: string;
  /** Tanda wajib di UI (server juga memvalidasi ulang). */
  wajib?: boolean;
  textarea?: boolean;
  baris?: number;
  /** Input bertipe date (format YYYY-MM-DD). */
  tanggal?: boolean;
  /** Batas panjang karakter → atribut maxLength (sama dengan BATAS di server). */
  maks?: number;
  /** Field memakai dropdown berisi daftar ini (+ "Lainnya (ketik sendiri)"). */
  pilihan?: readonly string[];
}

/**
 * Opsi umum dropdown Kategori (dokumentasi): kategori kegiatan yang memang
 * umum dipakai. Nilai di luar daftar ini dipilih lewat "Lainnya (ketik
 * sendiri)" lalu diketik manual — bebas, tapi tidak menumpuk di dropdown.
 * Menambah kategori umum = tambah satu entri di sini.
 */
export const OPSI_KATEGORI = ['Workshop', 'Kunjungan', 'Demo'] as const;
/** Nilai internal `<select>` yang mengaktifkan input teks bebas. */
export const KATEGORI_LAINNYA = '__lainnya';

/** Definisi form dokumentasi & berita — urutan array = urutan render. Kursus,
    tim, & profil punya form sendiri (KursusAdmin/TimAdmin/ProfilAdmin). */
const FIELD: Record<JenisDaftar, FieldDef[]> = {
  dokumentasi: [
    { kunci: 'judul', label: 'Judul', wajib: true, maks: 200 },
    { kunci: 'tanggal', label: 'Tanggal', wajib: true, tanggal: true },
    { kunci: 'kategori', label: 'Kategori', wajib: true, maks: 100, pilihan: OPSI_KATEGORI },
    { kunci: 'gambar', label: 'Gambar (file JPG/PNG/WebP, maks 2 MB)' },
    { kunci: 'deskripsi', label: 'Deskripsi', wajib: true, textarea: true, maks: 10000 },
  ],
  berita: [
    { kunci: 'judul', label: 'Judul', wajib: true, maks: 200 },
    { kunci: 'tanggal', label: 'Tanggal', wajib: true, tanggal: true },
    { kunci: 'penulis', label: 'Penulis', wajib: true, maks: 100 },
    { kunci: 'gambar', label: 'Gambar (file JPG/PNG/WebP, maks 2 MB)' },
    { kunci: 'ringkasan', label: 'Ringkasan', wajib: true, textarea: true, maks: 500 },
    { kunci: 'isi', label: 'Isi', wajib: true, textarea: true, baris: 8, maks: 20000 },
  ],
};

interface Pesan {
  teks: string;
  sukses: boolean;
}

/** Form kosong — tanggal default hari ini (UTC) agar operator tinggal sesuaikan. */
function formKosong(): Record<string, string> {
  return {
    judul: '',
    tanggal: new Date().toISOString().slice(0, 10),
    kategori: '',
    penulis: '',
    ringkasan: '',
    isi: '',
    gambar: '',
    deskripsi: '',
  };
}

/** Isi form dari item yang mau diedit (field asing jenis lain → string kosong). */
function formDariItem(item: ItemAdmin): Record<string, string> {
  return {
    judul: item.judul,
    tanggal: item.tanggal,
    gambar: item.gambar ?? '',
    kategori: 'kategori' in item ? item.kategori : '',
    deskripsi: 'deskripsi' in item ? item.deskripsi : '',
    ringkasan: 'ringkasan' in item ? item.ringkasan : '',
    isi: 'isi' in item ? item.isi : '',
    penulis: 'penulis' in item ? item.penulis : '',
  };
}

/** Susun body JSON hanya dari field milik jenis aktif. */
function bodyDariForm(form: Record<string, string>, jenis: JenisDaftar): Record<string, string> {
  return Object.fromEntries(FIELD[jenis].map((f) => [f.kunci, form[f.kunci] ?? '']));
}

/**
 * Nilai `<select>` untuk field bertipe pilihan: kosong → placeholder; nilai
 * yang ada di daftar opsi → nilai itu sendiri; nilai di luar daftar (kategori
 * custom lama) → "Lainnya (ketik sendiri)" supaya ikut tampil di input teks.
 */
function nilaiPilihan(f: FieldDef, form: Record<string, string>): string {
  const nilai = form[f.kunci] ?? '';
  if (nilai === '') return '';
  return f.pilihan?.includes(nilai) === true ? nilai : KATEGORI_LAINNYA;
}

export default function Admin() {
  const [token, setToken] = useState<string | null>(
    () => localStorage.getItem(KEY_TOKEN_ADMIN),
  );
  const [jenis, setJenis] = useState<Jenis>('dokumentasi');
  const [daftar, setDaftar] = useState<ItemAdmin[]>([]);
  const [mode, setMode] = useState<'daftar' | 'tambah' | 'ubah'>('daftar');
  const [slugEdit, setSlugEdit] = useState<string | null>(null);
  const [form, setForm] = useState<Record<string, string>>(formKosong);
  /**
   * Nilai `<select>` untuk field bertipe pilihan (mis. Kategori) — dipisah dari
   * `form` supaya pilihan "Lainnya (ketik sendiri)" tetap terpilih walau isinya
   * masih kosong (bila disimpan di form, memilih Lainnya langsung balik ke
   * placeholder). Di-reset tiap form dibuka/direset.
   */
  const [pilihanAktif, setPilihanAktif] = useState<Record<string, string>>({});
  /** File gambar baru (input file) + pratinjau lokalnya; null = tidak diganti. */
  const [fileGambar, setFileGambar] = useState<File | null>(null);
  const [pratinjau, setPratinjau] = useState<string | null>(null);
  const [pesan, setPesan] = useState<Pesan | null>(null);
  const [password, setPassword] = useState('');

  /** Muat daftar sesuai jenis aktif (fallback [] bila backend mati). Kursus,
      tim, & profil dimuat komponennya sendiri (KursusAdmin/TimAdmin/ProfilAdmin). */
  async function muatDaftar(j: JenisDaftar): Promise<void> {
    const items = await ambilDaftar<ItemAdmin>(`/${j}`, []);
    setDaftar(items);
  }

  /** Ganti file gambar: simpan file + buat pratinjau lokal. */
  function pilihGambar(event: ChangeEvent<HTMLInputElement>): void {
    const dipilih = event.target.files?.[0] ?? null;
    bersihkanGambar();
    setFileGambar(dipilih);
    // jsdom (unit test) tidak punya createObjectURL — pratinjau hanya di browser.
    if (dipilih !== null && typeof URL.createObjectURL === 'function') {
      setPratinjau(URL.createObjectURL(dipilih));
    }
  }

  /** Bersihkan pilihan file + pratinjau (dipanggil tiap ganti mode/jenis/selesai simpan). */
  function bersihkanGambar(): void {
    setPratinjau((lama) => {
      if (lama !== null && typeof URL.revokeObjectURL === 'function') URL.revokeObjectURL(lama);
      return null;
    });
    setFileGambar(null);
  }

  useEffect(() => {
    if (token === null) {
      setDaftar([]);
      return;
    }
    // Kursus/tim/profil memakai komponen admin sendiri (daftar milik section-nya).
    if (jenis !== 'dokumentasi' && jenis !== 'berita') {
      setDaftar([]);
      return;
    }
    void muatDaftar(jenis);
    // muatDaftar stabil (closure tanpa state); sengaja hanya bergantung token & jenis.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token, jenis]);

  function keluar(): void {
    localStorage.removeItem(KEY_TOKEN_ADMIN);
    setToken(null);
    setDaftar([]);
    setMode('daftar');
    setSlugEdit(null);
    bersihkanGambar();
  }

  /** Tampilkan error aksi tulis; 401 = sesi kedaluwarsa → keluar otomatis. */
  function tanganiErrorAksi(error: unknown): void {
    const status = (error as { status?: number } | null)?.status;
    if (status === 401) {
      keluar();
      setPesan({ teks: 'Sesi berakhir — silakan masuk kembali.', sukses: false });
      return;
    }
    setPesan({
      teks: error instanceof Error ? error.message : 'Terjadi kesalahan yang tidak dikenal',
      sukses: false,
    });
  }

  async function masuk(event: FormEvent): Promise<void> {
    event.preventDefault();
    setPesan(null);
    try {
      const hasil = await kirimJsonAdmin<{ token: string }>('/admin/login', {
        method: 'POST',
        body: { password },
      });
      localStorage.setItem(KEY_TOKEN_ADMIN, hasil.token);
      setToken(hasil.token);
      setPassword('');
    } catch (error) {
      // Login gagal → tampilkan pesan server apa adanya (mis. "Password salah").
      setPesan({
        teks: error instanceof Error ? error.message : 'Gagal masuk',
        sukses: false,
      });
    }
  }

  async function simpan(event: FormEvent): Promise<void> {
    event.preventDefault();
    if (token === null || mode === 'daftar' || (jenis !== 'dokumentasi' && jenis !== 'berita')) {
      return;
    }
    setPesan(null);
    const ubah = mode === 'ubah' && slugEdit !== null;
    try {
      // Gambar berupa file: unggah dulu, URL hasilnya masuk body.
      // Tanpa file baru → pertahankan nilai lama (URL lama / kosong).
      const body = bodyDariForm(form, jenis);
      if (fileGambar !== null) {
        const unggah = await kirimFileAdmin('/admin/upload', fileGambar, { token });
        body.gambar = unggah.url;
      }
      const hasil = await kirimJsonAdmin<ItemAdmin>(
        ubah ? `/${jenis}/${slugEdit}` : `/${jenis}`,
        { method: ubah ? 'PUT' : 'POST', body, token },
      );
      setPesan({
        teks: ubah
          ? `Konten "${hasil.judul}" diperbarui.`
          : `Konten "${hasil.judul}" tersimpan.`,
        sukses: true,
      });
      setMode('daftar');
      setSlugEdit(null);
      setForm(formKosong());
      setPilihanAktif({});
      bersihkanGambar();
      await muatDaftar(jenis);
    } catch (error) {
      tanganiErrorAksi(error);
    }
  }

  async function hapus(item: ItemAdmin): Promise<void> {
    if (token === null || (jenis !== 'dokumentasi' && jenis !== 'berita')) return;
    const yakin = window.confirm(`Hapus "${item.judul}"? Tindakan ini tidak bisa dibatalkan.`);
    if (!yakin) return;
    setPesan(null);
    try {
      await kirimJsonAdmin(`/${jenis}/${item.slug}`, { method: 'DELETE', token });
      setPesan({ teks: `Konten "${item.judul}" dihapus.`, sukses: true });
      await muatDaftar(jenis);
    } catch (error) {
      tanganiErrorAksi(error);
    }
  }

  /**
   * Bersihkan file unggahan tidak terpakai (Prioritas 2): file gambar di
   * server yang tidak lagi dirujuk kolom manapun (sisa edit/hapus konten).
   */
  async function bersihkanGambarTidakTerpakai(): Promise<void> {
    if (token === null) return;
    const yakin = window.confirm(
      'Hapus file gambar di server yang tidak lagi dipakai konten manapun? Tindakan ini tidak bisa dibatalkan.',
    );
    if (!yakin) return;
    setPesan(null);
    try {
      const hasil = await kirimJsonAdmin<{ kering: boolean; items: string[] }>(
        '/admin/uploads/bersihkan',
        { method: 'POST', body: {}, token },
      );
      setPesan({
        teks:
          hasil.items.length === 0
            ? 'Semua gambar masih dipakai — tidak ada yang dibersihkan.'
            : `${hasil.items.length} gambar tidak terpakai dihapus.`,
        sukses: true,
      });
    } catch (error) {
      tanganiErrorAksi(error);
    }
  }

  const elemenPesan =
    pesan === null ? null : (
      <p
        role={pesan.sukses ? 'status' : 'alert'}
        className={`mt-4 rounded-lg px-4 py-3 text-sm ${
          pesan.sukses ? 'bg-soft text-emerald-800' : 'bg-red-50 text-red-800'
        }`}
      >
        {pesan.teks}
      </p>
    );

  // — Layar login (belum ada token) ————————————————————————————————
  if (token === null) {
    return (
      <main className="mx-auto max-w-md px-6 py-16">
        <h1 className="font-display text-3xl font-bold">Masuk Admin</h1>
        <p className="mt-2 text-sm text-muted">
          Dashboard internal AI Center Ubaya — kelola dokumentasi, berita, kursus, tim &
          testimoni. Konten hero, profil, inference & layanan diubah di kode frontend
          (src/data/).
        </p>
        <form onSubmit={masuk} className="mt-8 space-y-4">
          <div>
            <label htmlFor="admin-password" className="block text-sm font-semibold">
              Password
            </label>
            <input
              id="admin-password"
              type="password"
              autoComplete="current-password"
              required
              className="mt-1 w-full rounded-lg border border-line px-3 py-2"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
            />
          </div>
          <button
            type="submit"
            className="rounded-lg bg-brand px-5 py-2 font-semibold text-white hover:opacity-90"
          >
            Masuk
          </button>
          {elemenPesan}
        </form>
        <p className="mt-8 text-sm">
          <a href="/beranda" className="underline">
            ← Kembali ke situs
          </a>
        </p>
      </main>
    );
  }

  // — Layar dashboard ————————————————————————————————————————————
  const LABEL_JENIS: Record<Jenis, string> = {
    dokumentasi: 'Dokumentasi',
    berita: 'Berita',
    kursus: 'Kursus',
    tim: 'Tim',
    testimoni: 'Testimoni',
  };
  const labelJenis = LABEL_JENIS[jenis];
  /** Handler 401 bersama untuk section admin yang punya token sendiri. */
  const sesiBerakhir = (): void => {
    keluar();
    setPesan({ teks: 'Sesi berakhir — silakan masuk kembali.', sukses: false });
  };
  return (
    <main className="mx-auto max-w-4xl px-6 py-10">
      <header className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold">Dashboard Admin</h1>
          <p className="mt-1 text-sm text-muted">
            Kelola dokumentasi, berita, kursus, tim & testimoni. Konten hero, profil,
            inference & layanan diubah langsung di kode frontend (src/data/).
          </p>
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => void bersihkanGambarTidakTerpakai()}
            className="rounded-lg border border-line px-4 py-2 text-sm font-semibold hover:bg-soft"
          >
            Bersihkan gambar tidak terpakai
          </button>
          <button
            type="button"
            onClick={() => {
              if (window.confirm('Yakin keluar dari dashboard admin?')) keluar();
            }}
            className="rounded-lg border-2 border-red-300 px-4 py-2 text-sm font-bold text-red-700 hover:bg-red-50"
          >
            Keluar
          </button>
        </div>
      </header>

      <div role="tablist" aria-label="Jenis konten" className="mt-6 flex flex-wrap gap-2">
        {(['dokumentasi', 'berita', 'kursus', 'tim', 'testimoni'] as const).map((j) => (
          <button
            key={j}
            type="button"
            role="tab"
            aria-selected={jenis === j}
            onClick={() => {
              setJenis(j);
              setMode('daftar');
              setSlugEdit(null);
              setPesan(null);
              bersihkanGambar();
            }}
            className={`rounded-lg px-4 py-2 text-sm font-semibold ${
              jenis === j ? 'bg-brand text-white' : 'border border-line hover:bg-soft'
            }`}
          >
            {LABEL_JENIS[j]}
          </button>
        ))}
      </div>

      {/* Satu titik render pesan aksi (simpan/hapus/bersih-bersih) — tab lain
          punya state pesan sendiri di komponennya masing-masing. */}
      {elemenPesan}

      {jenis === 'kursus' ? (
        <KursusAdmin token={token} gagal401={sesiBerakhir} />
      ) : jenis === 'tim' ? (
        <TimAdmin token={token} gagal401={sesiBerakhir} />
      ) : jenis === 'testimoni' ? (
        <TestimoniAdmin token={token} gagal401={sesiBerakhir} />
      ) : (
      <section className="mt-6">
        <div className="flex items-center justify-between gap-3">
          <h2 className="font-display text-xl font-bold">{labelJenis}</h2>
          {mode === 'daftar' && (
            <button
              type="button"
              onClick={() => {
                setForm(formKosong());
                setPilihanAktif({});
                bersihkanGambar();
                setMode('tambah');
                setPesan(null);
              }}
              className="rounded-lg bg-brand px-4 py-2 text-sm font-semibold text-white hover:opacity-90"
            >
              + Tambah baru
            </button>
          )}
        </div>

        {mode === 'daftar' ? (
          daftar.length === 0 ? (
            <p className="mt-4 text-sm text-muted">Belum ada konten {labelJenis}.</p>
          ) : (
            <ul className="mt-4 divide-y divide-line rounded-xl border border-line">
              {daftar.map((item) => (
                <li key={item.slug} className="flex items-center gap-3 px-4 py-3">
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-semibold">{item.judul}</p>
                    <p className="text-xs text-muted">
                      {item.tanggal}
                      {'kategori' in item ? ` · ${item.kategori}` : ''}
                      {'penulis' in item ? ` · ${item.penulis}` : ''}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setForm(formDariItem(item));
                      setPilihanAktif({});
                      bersihkanGambar();
                      setSlugEdit(item.slug);
                      setMode('ubah');
                      setPesan(null);
                    }}
                    className="rounded-lg border border-line px-3 py-1.5 text-sm font-semibold hover:bg-soft"
                  >
                    Ubah
                  </button>
                  <button
                    type="button"
                    onClick={() => void hapus(item)}
                    className="rounded-lg border border-red-200 px-3 py-1.5 text-sm font-semibold text-red-700 hover:bg-red-50"
                  >
                    Hapus
                  </button>
                </li>
              ))}
            </ul>
          )
        ) : (
          <form onSubmit={simpan} className="mt-4 space-y-4 rounded-xl border border-line p-5">
            <h3 className="font-semibold">
              {mode === 'ubah' ? `Ubah konten — ${slugEdit ?? ''}` : 'Tambah konten baru'}
            </h3>
            {FIELD[jenis].map((f) => (
              <div key={f.kunci}>
                <label htmlFor={`field-${f.kunci}`} className="block text-sm font-semibold">
                  {f.label}
                  {f.wajib === true ? ' *' : ''}
                </label>
                {f.kunci === 'gambar' ? (
                  // Gambar berupa FILE (bukan URL): diunggah ke server saat Simpan.
                  <div>
                    <input
                      id="field-gambar"
                      type="file"
                      accept="image/jpeg,image/png,image/webp"
                      onChange={pilihGambar}
                      className="mt-1 w-full rounded-lg border border-line px-3 py-2"
                    />
                    <p className="mt-1 text-xs text-muted">
                      {form.gambar !== ''
                        ? 'Gambar lama dipertahankan bila tidak memilih file baru.'
                        : 'Belum ada gambar — kartu memakai panel pengganti bermerek.'}
                    </p>
                    {pratinjau !== null && (
                      <img
                        src={pratinjau}
                        alt="Pratinjau gambar baru"
                        className="mt-2 aspect-video w-full max-w-xs rounded-lg border border-line bg-soft object-cover"
                      />
                    )}
                  </div>
                ) : f.pilihan !== undefined ? (
                  // Dropdown opsi umum; "Lainnya (ketik sendiri)" membuka input
                  // teks di bawahnya untuk kategori di luar daftar.
                  <div className="mt-1">
                    <select
                      id={`field-${f.kunci}`}
                      required={f.wajib === true}
                      className="w-full rounded-lg border border-line px-3 py-2"
                      value={pilihanAktif[f.kunci] ?? nilaiPilihan(f, form)}
                      onChange={(event) => {
                        const nilai = event.target.value;
                        setPilihanAktif((prev) => ({ ...prev, [f.kunci]: nilai }));
                        setForm((prev) => ({
                          ...prev,
                          // Opsi umum → langsung jadi nilai; "Lainnya" → kosongkan
                          // dulu supaya operator mengetik nilai barunya sendiri.
                          [f.kunci]: nilai === KATEGORI_LAINNYA ? '' : nilai,
                        }));
                      }}
                    >
                      <option value="">— pilih kategori —</option>
                      {f.pilihan.map((opsi) => (
                        <option key={opsi} value={opsi}>
                          {opsi}
                        </option>
                      ))}
                      <option value={KATEGORI_LAINNYA}>Lainnya (ketik sendiri)</option>
                    </select>
                    {(pilihanAktif[f.kunci] ?? nilaiPilihan(f, form)) === KATEGORI_LAINNYA && (
                      <div className="mt-2">
                        <label
                          htmlFor={`field-${f.kunci}-teks`}
                          className="block text-xs font-semibold text-muted"
                        >
                          Tulis kategori sendiri
                        </label>
                        <input
                          id={`field-${f.kunci}-teks`}
                          type="text"
                          required={f.wajib === true}
                          maxLength={f.maks}
                          className="mt-1 w-full rounded-lg border border-line px-3 py-2"
                          value={form[f.kunci] ?? ''}
                          onChange={(event) =>
                            setForm((prev) => ({ ...prev, [f.kunci]: event.target.value }))
                          }
                        />
                      </div>
                    )}
                  </div>
                ) : f.textarea === true ? (
                  <textarea
                    id={`field-${f.kunci}`}
                    required={f.wajib === true}
                    rows={f.baris ?? 4}
                    maxLength={f.maks}
                    className="mt-1 w-full rounded-lg border border-line px-3 py-2"
                    value={form[f.kunci] ?? ''}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, [f.kunci]: event.target.value }))
                    }
                  />
                ) : (
                  <input
                    id={`field-${f.kunci}`}
                    type={f.tanggal === true ? 'date' : 'text'}
                    required={f.wajib === true}
                    maxLength={f.maks}
                    className="mt-1 w-full rounded-lg border border-line px-3 py-2"
                    value={form[f.kunci] ?? ''}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, [f.kunci]: event.target.value }))
                    }
                  />
                )}
              </div>
            ))}
            <div className="flex gap-2">
              <button
                type="submit"
                className="rounded-lg bg-brand px-5 py-2 font-semibold text-white hover:opacity-90"
              >
                Simpan
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('daftar');
                  setSlugEdit(null);
                  setPesan(null);
                  bersihkanGambar();
                }}
                className="rounded-lg border border-line px-5 py-2 font-semibold hover:bg-soft"
              >
                Batal
              </button>
            </div>
          </form>
        )}
      </section>
      )}

      <p className="mt-10 text-sm">
        <a href="/beranda" className="underline">
          ← Kembali ke situs
        </a>
      </p>
    </main>
  );
}

/** Pecah textarea menjadi daftar baris (satu item per baris). */
function barisDaftar(teks: string): string[] {
  return teks
    .split('\n')
    .map((b) => b.trim())
    .filter((b) => b !== '');
}

/**
 * Normalisasi kuis modul sebelum dikirim ke server: soal tanpa pertanyaan
 * dibuang; opsi kosong dibuang; soal dengan < 2 opsi tersisa — atau opsi
 * `kunci` (jawaban benar) ikut kosong — dibuang juga (jawabannya sudah tidak
 * bisa dipastikan). `kunci` dihitung ulang sesuai opsi yang bertahan.
 */
function kuisSiapKirim(quiz: Soal[] | undefined): Soal[] {
  if (!quiz) return [];
  const siap: Soal[] = [];
  for (const s of quiz) {
    const pertanyaan = s.pertanyaan.trim();
    if (pertanyaan === '') continue;
    const opsi: string[] = [];
    let kunciBaru = -1;
    s.opsi.forEach((o, idx) => {
      const teks = o.trim();
      if (teks === '') return;
      if (idx === s.kunci) kunciBaru = opsi.length;
      opsi.push(teks);
    });
    if (opsi.length < 2 || kunciBaru === -1) continue;
    siap.push({ pertanyaan, opsi, kunci: kunciBaru });
  }
  return siap;
}

const MODUL_KOSONG: Modul = { judul: '', deskripsi: '', meta: '', video: '', quiz: [] };

/** Saran level & format pada form kursus (datalist — teks bebas tetap boleh). */
const OPSI_LEVEL = ['Pemula', 'Menengah', 'Lanjutan'];
const OPSI_FORMAT = ['Online mandiri', 'Tatap muka', 'Hybrid'];

/** Tebak inisial avatar dari nama instruktur (2 huruf pertama 2 kata pertama). */
function autoInisial(nama: string): string {
  const kata = nama.trim().split(/\s+/).filter(Boolean);
  if (kata.length === 0) return 'AI';
  return kata
    .slice(0, 2)
    .map((k) => k[0])
    .join('')
    .toUpperCase();
}

/** Ringkasan singkat video & kuis satu modul — badge di baris modul. */
function ringkasanVideoKuis(m: Modul): string {
  const video = (m.video ?? '').trim() === '' ? 'tanpa video' : 'video terisi';
  const jmlSoal = (m.quiz ?? []).length;
  return `${video} · ${jmlSoal === 0 ? 'tanpa kuis' : `${jmlSoal} soal kuis`}`;
}

/** Bagian berjudul dalam form admin — pengelompok visual + petunjuk singkat. */
function BagianForm({
  nomor,
  judul,
  petunjuk,
  children,
}: {
  nomor: number;
  judul: string;
  petunjuk?: string;
  children: ReactNode;
}) {
  return (
    <section className="rounded-xl border border-line bg-soft/50 p-3">
      <h4 className="text-sm font-bold uppercase tracking-[0.12em] text-brand">
        {nomor}. {judul}
      </h4>
      {petunjuk && <p className="mt-0.5 text-xs text-muted">{petunjuk}</p>}
      <div className="mt-3 space-y-3">{children}</div>
    </section>
  );
}

/** Section CRUD kursus + editor daftar modul (tab "Kursus" di dashboard). */
function KursusAdmin({ token, gagal401 }: { token: string; gagal401: () => void }) {
  const [daftar, setDaftar] = useState<Kursus[]>([]);
  const [mode, setMode] = useState<'daftar' | 'tambah' | 'ubah'>('daftar');
  const [kodeEdit, setKodeEdit] = useState<string | null>(null);
  const [k, setK] = useState({
    judul: '',
    deskripsi: '',
    tentang: '',
    durasi: '',
    level: '',
    format: '',
    instruktur: '',
    peran: '',
    inisial: '',
  });
  /** Satu label peserta (dropdown) — menentukan kode otomatis & isi `target`. */
  const [targetPilihan, setTargetPilihan] = useState('');
  /** Target asli item saat mode ubah — dasar catatan bila data lama > 1 target. */
  const [targetLama, setTargetLama] = useState<string[]>([]);
  const [hasilText, setHasilText] = useState('');
  const [modul, setModul] = useState<Modul[]>([{ ...MODUL_KOSONG }]);
  const [pesan, setPesan] = useState<Pesan | null>(null);

  async function muat(): Promise<void> {
    setDaftar(await ambilDaftar<Kursus>('/kursus', []));
  }

  useEffect(() => {
    void muat();
    // Sekali saat tab dibuka (daftar milik section ini sendiri).
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function atur(kunci: keyof typeof k, nilai: string): void {
    setK((prev) => ({ ...prev, [kunci]: nilai }));
  }

  function aturModul(index: number, kunci: keyof Modul, nilai: string): void {
    setModul((prev) => prev.map((m, i) => (i === index ? { ...m, [kunci]: nilai } : m)));
  }

  /** Ubah satu soal kuis modul `index` (field parsial: pertanyaan/kunci/opsi). */
  function aturSoal(index: number, soal: number, nilai: Partial<Soal>): void {
    setModul((prev) =>
      prev.map((m, i) =>
        i === index
          ? { ...m, quiz: (m.quiz ?? []).map((s, j) => (j === soal ? { ...s, ...nilai } : s)) }
          : m,
      ),
    );
  }

  /** Tambah soal kosong (2 opsi, kunci 0) ke modul `index`. */
  function tambahSoal(index: number): void {
    setModul((prev) =>
      prev.map((m, i) =>
        i === index
          ? { ...m, quiz: [...(m.quiz ?? []), { pertanyaan: '', opsi: ['', ''], kunci: 0 }] }
          : m,
      ),
    );
  }

  function hapusSoal(index: number, soal: number): void {
    setModul((prev) =>
      prev.map((m, i) =>
        i === index ? { ...m, quiz: (m.quiz ?? []).filter((_, j) => j !== soal) } : m,
      ),
    );
  }

  function aturOpsi(index: number, soal: number, opsi: number, nilai: string): void {
    setModul((prev) =>
      prev.map((m, i) =>
        i === index
          ? {
              ...m,
              quiz: (m.quiz ?? []).map((s, j) =>
                j === soal ? { ...s, opsi: s.opsi.map((o, k) => (k === opsi ? nilai : o)) } : s,
              ),
            }
          : m,
      ),
    );
  }

  function tambahOpsi(index: number, soal: number): void {
    setModul((prev) =>
      prev.map((m, i) =>
        i === index
          ? {
              ...m,
              quiz: (m.quiz ?? []).map((s, j) =>
                j === soal ? { ...s, opsi: [...s.opsi, ''] } : s,
              ),
            }
          : m,
      ),
    );
  }

  /** Hapus opsi; `kunci` ikut menyesuaikan agar tetap menunjuk opsi valid. */
  function hapusOpsi(index: number, soal: number, opsi: number): void {
    setModul((prev) =>
      prev.map((m, i) =>
        i === index
          ? {
              ...m,
              quiz: (m.quiz ?? []).map((s, j) => {
                if (j !== soal) return s;
                const opsiBaru = s.opsi.filter((_, k) => k !== opsi);
                const kunciBaru = s.kunci > opsi ? s.kunci - 1 : s.kunci;
                return { ...s, opsi: opsiBaru, kunci: Math.min(kunciBaru, opsiBaru.length - 1) };
              }),
            }
          : m,
      ),
    );
  }

  function mulaiTambah(): void {
    setK({ judul: '', deskripsi: '', tentang: '', durasi: '', level: '', format: '', instruktur: '', peran: '', inisial: '' });
    setTargetPilihan('');
    setTargetLama([]);
    setHasilText('');
    setModul([{ ...MODUL_KOSONG }]);
    setKodeEdit(null);
    setMode('tambah');
    setPesan(null);
  }

  function mulaiUbah(item: Kursus): void {
    setK({
      judul: item.judul,
      deskripsi: item.deskripsi,
      tentang: item.tentang,
      durasi: item.durasi,
      level: item.level,
      format: item.format,
      instruktur: item.instruktur,
      peran: item.peran,
      inisial: item.inisial,
    });
    // Dropdown hanya memuat 4 label katalog: target pertama jadi pilihan awal
    // (label di luar katalog dipaksa kosong → admin wajib pilih ulang).
    const pertama = item.target[0] ?? '';
    setTargetPilihan(LABEL_PESERTA.includes(pertama) ? pertama : '');
    setTargetLama(item.target);
    setHasilText(item.hasil.join('\n'));
    // Normalisasi field baru: baris lama (seed) bisa tanpa video/quiz.
    setModul(
      item.modul.length > 0
        ? item.modul.map((m) => ({ ...m, video: m.video ?? '', quiz: m.quiz ?? [] }))
        : [{ ...MODUL_KOSONG }],
    );
    setKodeEdit(item.kode);
    setMode('ubah');
    setPesan(null);
  }

  function tanganiError(error: unknown): void {
    if ((error as { status?: number } | null)?.status === 401) {
      gagal401();
      return;
    }
    setPesan({
      teks: error instanceof Error ? error.message : 'Terjadi kesalahan yang tidak dikenal',
      sukses: false,
    });
  }

  // Kode baru dibuat dari peserta terpilih + kode yang sudah terpakai (read-only
  // di form); saat edit, kode kunci (kodeEdit) dipakai apa adanya.
  const kodeBaru = kodeOtomatis(targetPilihan, daftar.map((d) => d.kode));

  async function simpan(event: FormEvent): Promise<void> {
    event.preventDefault();
    if (mode === 'daftar') return;
    setPesan(null);
    const ubah = mode === 'ubah' && kodeEdit !== null;
    if (targetPilihan === '') {
      setPesan({ teks: 'Target peserta wajib dipilih (menentukan kode otomatis).', sukses: false });
      return;
    }
    if (!ubah && kodeBaru === '') {
      setPesan({
        teks: 'Kode otomatis belum bisa dibuat — pilih peserta yang punya prefiks (M/D/G/U).',
        sukses: false,
      });
      return;
    }
    const kode = ubah ? kodeEdit : kodeBaru;
    const body = {
      kode,
      judul: k.judul,
      deskripsi: k.deskripsi,
      tentang: k.tentang,
      durasi: k.durasi,
      level: k.level,
      format: k.format,
      instruktur: k.instruktur,
      peran: k.peran,
      // Inisial opsional di form — kosong → 2 huruf pertama dari nama instruktur.
      inisial: k.inisial.trim() === '' ? autoInisial(k.instruktur) : k.inisial.trim(),
      target: [targetPilihan],
      hasil: barisDaftar(hasilText),
      // Baris modul yang ketiga kolomnya kosong diabaikan (sisa divalidasi server);
      // video & kuis ikut dikirim ('' → null, daftar soal kosong → []).
      modul: modul
        .map((m) => ({
          judul: m.judul.trim(),
          deskripsi: m.deskripsi.trim(),
          meta: m.meta.trim(),
          video: (m.video ?? '').trim() === '' ? null : (m.video ?? '').trim(),
          quiz: kuisSiapKirim(m.quiz),
        }))
        .filter((m) => m.judul !== '' || m.deskripsi !== '' || m.meta !== ''),
    };
    try {
      const hasil = await kirimJsonAdmin<Kursus>(ubah ? `/kursus/${kodeEdit}` : '/kursus', {
        method: ubah ? 'PUT' : 'POST',
        body,
        token,
      });
      setPesan({
        teks: ubah ? `Kursus "${hasil.judul}" diperbarui.` : `Kursus "${hasil.judul}" tersimpan.`,
        sukses: true,
      });
      setMode('daftar');
      setKodeEdit(null);
      await muat();
    } catch (error) {
      tanganiError(error);
    }
  }

  async function hapus(item: Kursus): Promise<void> {
    const yakin = window.confirm(`Hapus kursus "${item.judul}" (${item.kode})? Tindakan ini tidak bisa dibatalkan.`);
    if (!yakin) return;
    setPesan(null);
    try {
      await kirimJsonAdmin(`/kursus/${item.kode}`, { method: 'DELETE', token });
      setPesan({ teks: `Kursus "${item.judul}" dihapus.`, sukses: true });
      await muat();
    } catch (error) {
      tanganiError(error);
    }
  }

  const elemenPesan =
    pesan === null ? null : (
      <p
        role={pesan.sukses ? 'status' : 'alert'}
        className={`mt-4 rounded-lg px-4 py-3 text-sm ${
          pesan.sukses ? 'bg-soft text-emerald-800' : 'bg-red-50 text-red-800'
        }`}
      >
        {pesan.teks}
      </p>
    );

  // Batas panjang tiap input = BATAS server (lib/tulis) → atribut maxLength.
  const inputCls = 'mt-1 w-full rounded-lg border border-line px-3 py-2';
  const labelCls = 'block text-sm font-semibold';

  return (
    <section className="mt-6">
      <div className="flex items-center justify-between gap-3">
        <h2 className="font-display text-xl font-bold">Kursus</h2>
        {mode === 'daftar' && (
          <button
            type="button"
            onClick={mulaiTambah}
            className="rounded-lg bg-brand px-4 py-2 text-sm font-semibold text-white hover:opacity-90"
          >
            + Tambah baru
          </button>
        )}
      </div>

      {elemenPesan}

      {mode === 'daftar' ? (
        daftar.length === 0 ? (
          <p className="mt-4 text-sm text-muted">Belum ada konten Kursus.</p>
        ) : (
          <ul className="mt-4 divide-y divide-line rounded-xl border border-line">
            {daftar.map((item) => (
              <li key={item.kode} className="flex items-center gap-3 px-4 py-3">
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold">{item.judul}</p>
                  <p className="text-xs text-muted">
                    {item.kode} · {item.durasi} · {item.level} · {item.modul.length} modul
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => mulaiUbah(item)}
                  className="rounded-lg border border-line px-3 py-1.5 text-sm font-semibold hover:bg-soft"
                >
                  Ubah
                </button>
                <button
                  type="button"
                  onClick={() => void hapus(item)}
                  className="rounded-lg border border-red-200 px-3 py-1.5 text-sm font-semibold text-red-700 hover:bg-red-50"
                >
                  Hapus
                </button>
              </li>
            ))}
          </ul>
        )
      ) : (
        <form onSubmit={simpan} className="mt-4 space-y-4 rounded-xl border border-line p-5">
          <h3 className="font-semibold">
            {mode === 'ubah' ? `Ubah kursus — ${kodeEdit ?? ''}` : 'Tambah kursus baru'}
          </h3>
          <p className="text-xs text-muted">
            Isi dari atas ke bawah — yang bertanda * wajib diisi. Bagian "Video & kuis" boleh
            dibiarkan tertutup dan kosong.
          </p>
          {/* 1) Audiens dulu — target menentukan kode otomatis. */}
          <BagianForm
            nomor={1}
            judul="Audiens & kode"
            petunjuk="Pilih siapa pesertanya; kode kursus dibuat otomatis dari pilihan ini."
          >
            <div>
              <label htmlFor="kursus-target" className={labelCls}>
                Target peserta *{' '}
                <span className="font-normal text-muted">(menentukan kode otomatis)</span>
              </label>
              <select
                id="kursus-target"
                className={inputCls}
                value={targetPilihan}
                onChange={(event) => setTargetPilihan(event.target.value)}
              >
                <option value="">— pilih peserta —</option>
                {LABEL_PESERTA.map((label) => (
                  <option key={label} value={label}>
                    {label}
                  </option>
                ))}
              </select>
              {targetLama.length > 1 && (
                <p className="mt-1 text-xs text-muted">
                  Data lama punya {targetLama.length} target ({targetLama.join(', ')}) — simpan
                  akan menyimpan pilihan ini saja.
                </p>
              )}
            </div>
            <div>
              <label htmlFor="kursus-kode" className={labelCls}>
                {mode === 'ubah' ? 'Kode (kunci) *' : 'Kode (otomatis dari target peserta) *'}
              </label>
              <input
                id="kursus-kode"
                type="text"
                readOnly={mode === 'tambah'}
                disabled={mode === 'ubah'}
                placeholder={mode === 'ubah' ? '' : 'Pilih target peserta dulu'}
                className={`${inputCls} bg-soft`}
                value={mode === 'ubah' ? (kodeEdit ?? '') : kodeBaru}
              />
              {mode === 'ubah' ? (
                <p className="mt-1 text-xs text-muted">
                  Kode kunci tidak bisa diganti saat edit.
                </p>
              ) : (
                <p className="mt-1 text-xs text-muted">
                  Prefiks M (Mahasiswa) · D (Dosen) · G (Guru) · U (masyarakat umum) + nomor
                  berikutnya, mis. M01.
                </p>
              )}
            </div>
          </BagianForm>
          {/* 2) Teks inti kursus. */}
          <BagianForm
            nomor={2}
            judul="Isi kursus"
            petunjuk="Teks utama yang tampil di katalog dan halaman detail."
          >
            <div>
              <label htmlFor="kursus-judul" className={labelCls}>
                Judul *
              </label>
              <input
                id="kursus-judul"
                type="text"
                required
                maxLength={200}
                className={inputCls}
                value={k.judul}
                onChange={(event) => atur('judul', event.target.value)}
              />
            </div>
            <div>
              <label htmlFor="kursus-deskripsi" className={labelCls}>
                Deskripsi singkat *
              </label>
              <textarea
                id="kursus-deskripsi"
                required
                rows={3}
                maxLength={1000}
                placeholder="1–2 kalimat — tampil di kartu katalog."
                className={inputCls}
                value={k.deskripsi}
                onChange={(event) => atur('deskripsi', event.target.value)}
              />
            </div>
            <div>
              <label htmlFor="kursus-tentang" className={labelCls}>
                Tentang kursus (panjang) *
              </label>
              <textarea
                id="kursus-tentang"
                required
                rows={4}
                maxLength={20000}
                placeholder="Penjelasan lengkap kursus — tampil di halaman detail."
                className={inputCls}
                value={k.tentang}
                onChange={(event) => atur('tentang', event.target.value)}
              />
            </div>
          </BagianForm>
          {/* 3) Ikhtisar singkat yang tampil di kartu & hero detail. */}
          <BagianForm
            nomor={3}
            judul="Detail tampilan"
            petunjuk="Ikhtisar singkat di kartu katalog & baris fakta halaman detail."
          >
            <div>
              <label htmlFor="kursus-durasi" className={labelCls}>
                Durasi *
              </label>
              <input
                id="kursus-durasi"
                type="text"
                required
                maxLength={100}
                placeholder="mis. 4 sesi"
                className={inputCls}
                value={k.durasi}
                onChange={(event) => atur('durasi', event.target.value)}
              />
            </div>
            <div>
              <label htmlFor="kursus-level" className={labelCls}>
                Level *
              </label>
              <input
                id="kursus-level"
                type="text"
                required
                maxLength={100}
                list="kursus-level-opsi"
                placeholder="mis. Pemula — pilih dari saran atau ketik sendiri"
                className={inputCls}
                value={k.level}
                onChange={(event) => atur('level', event.target.value)}
              />
            </div>
            <div>
              <label htmlFor="kursus-format" className={labelCls}>
                Format *
              </label>
              <input
                id="kursus-format"
                type="text"
                required
                maxLength={100}
                list="kursus-format-opsi"
                placeholder="mis. Online mandiri — pilih dari saran atau ketik sendiri"
                className={inputCls}
                value={k.format}
                onChange={(event) => atur('format', event.target.value)}
              />
            </div>
            <div>
              <label htmlFor="kursus-hasil" className={labelCls}>
                Hasil belajar (satu per baris) *
              </label>
              <textarea
                id="kursus-hasil"
                required
                rows={3}
                placeholder={'Satu kemampuan peserta per baris, mis.:\nMerumuskan kata kunci riset'}
                className={inputCls}
                value={hasilText}
                onChange={(event) => setHasilText(event.target.value)}
              />
            </div>
            {/* Saran pilihan cepat (datalist) — teks bebas tetap diperbolehkan. */}
            <datalist id="kursus-level-opsi">
              {OPSI_LEVEL.map((o) => (
                <option key={o} value={o} />
              ))}
            </datalist>
            <datalist id="kursus-format-opsi">
              {OPSI_FORMAT.map((o) => (
                <option key={o} value={o} />
              ))}
            </datalist>
          </BagianForm>
          {/* 4) Instruktur. */}
          <BagianForm
            nomor={4}
            judul="Instruktur"
            petunjuk="Tampil di kartu katalog (nama) & halaman detail (kartu instruktur)."
          >
            <div>
              <label htmlFor="kursus-instruktur" className={labelCls}>
                Instruktur *
              </label>
              <input
                id="kursus-instruktur"
                type="text"
                required
                maxLength={200}
                placeholder="mis. Budi Santoso atau Tim Riset Ubaya AI Center"
                className={inputCls}
                value={k.instruktur}
                onChange={(event) => atur('instruktur', event.target.value)}
              />
            </div>
            <div>
              <label htmlFor="kursus-peran" className={labelCls}>
                Peran instruktur *
              </label>
              <input
                id="kursus-peran"
                type="text"
                required
                maxLength={200}
                placeholder="mis. Dosen dan praktisi riset AI"
                className={inputCls}
                value={k.peran}
                onChange={(event) => atur('peran', event.target.value)}
              />
            </div>
            <div>
              <label htmlFor="kursus-inisial" className={labelCls}>
                Inisial avatar (opsional){' '}
                <span className="font-normal text-muted">
                  — otomatis dari nama bila dikosongkan
                </span>
              </label>
              <input
                id="kursus-inisial"
                type="text"
                maxLength={10}
                placeholder="mis. BS"
                className={inputCls}
                value={k.inisial}
                onChange={(event) => atur('inisial', event.target.value)}
              />
            </div>
          </BagianForm>
          {/* 5) Modul — video & kuis disembunyikan di balik disclosure per modul. */}
          <BagianForm
            nomor={5}
            judul="Modul & materi"
            petunjuk="Urut tampil sebagai daftar materi. Video & kuis opsional — buka bila sudah siap."
          >
            <p className={labelCls}>Daftar modul *</p>
            <ol className="space-y-3">
              {modul.map((m, i) => (
                <li key={i} className="rounded-lg border border-line p-3">
                  <p className="flex items-center gap-2 text-xs font-bold text-muted">
                    Modul {i + 1}
                    <span
                      className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${
                        (m.video ?? '').trim() !== '' || (m.quiz ?? []).length > 0
                          ? 'bg-brand/10 text-brand'
                          : 'bg-soft text-muted'
                      }`}
                    >
                      {ringkasanVideoKuis(m)}
                    </span>
                  </p>
                  <input
                    type="text"
                    required
                    aria-label={`Judul modul ${i + 1}`}
                    placeholder="Judul modul"
                    maxLength={200}
                    className={`${inputCls} mt-2`}
                    value={m.judul}
                    onChange={(event) => aturModul(i, 'judul', event.target.value)}
                  />
                  <input
                    type="text"
                    required
                    aria-label={`Meta modul ${i + 1}`}
                    placeholder="Meta (mis. 4 video · 35 menit)"
                    maxLength={200}
                    className={inputCls}
                    value={m.meta}
                    onChange={(event) => aturModul(i, 'meta', event.target.value)}
                  />
                  <textarea
                    required
                    aria-label={`Deskripsi modul ${i + 1}`}
                    placeholder="Deskripsi modul"
                    rows={2}
                    maxLength={1000}
                    className={inputCls}
                    value={m.deskripsi}
                    onChange={(event) => aturModul(i, 'deskripsi', event.target.value)}
                  />
                  {/* Video & kuis opsional — tertutup default supaya form ringkas. */}
                  <details className="mt-2 rounded-md border border-line bg-soft/40 p-2">
                    <summary className="cursor-pointer text-sm font-semibold select-none">
                      Video &amp; kuis modul (opsional)
                    </summary>
                    <input
                      type="text"
                      aria-label={`Video modul ${i + 1}`}
                      placeholder="URL video YouTube/Vimeo (opsional)"
                      maxLength={300}
                      className={inputCls}
                      value={m.video ?? ''}
                      onChange={(event) => aturModul(i, 'video', event.target.value)}
                    />
                  <p className="mt-1 text-xs text-muted">
                    Kosongkan bila video belum ada — ruang belajar menampilkan "video menyusul".
                  </p>
                  {/* Kuis per modul (opsional): kosong = checkpoint dummy. */}
                  <div className="mt-2 rounded-md bg-soft p-2">
                    <p className="text-xs font-bold text-muted">Kuis modul (opsional)</p>
                    <ol className="mt-2 space-y-3">
                      {(m.quiz ?? []).map((s, si) => (
                        <li key={si} className="rounded-md border border-line bg-surface p-2">
                          <div className="flex items-center justify-between gap-2">
                            <p className="text-xs font-bold text-muted">Soal {si + 1}</p>
                            <button
                              type="button"
                              onClick={() => hapusSoal(i, si)}
                              className="text-xs font-semibold text-red-700 hover:underline"
                            >
                              Hapus soal
                            </button>
                          </div>
                          <input
                            type="text"
                            aria-label={`Pertanyaan ${si + 1} modul ${i + 1}`}
                            placeholder="Pertanyaan"
                            maxLength={300}
                            className={inputCls}
                            value={s.pertanyaan}
                            onChange={(event) =>
                              aturSoal(i, si, { pertanyaan: event.target.value })
                            }
                          />
                          <p className="mt-2 text-xs font-semibold text-muted">
                            Opsi (radio = jawaban benar)
                          </p>
                          <ul className="mt-1 space-y-1">
                            {s.opsi.map((o, oi) => (
                              <li key={oi} className="flex items-center gap-2">
                                <input
                                  type="radio"
                                  name={`kunci-${i}-${si}`}
                                  aria-label={`Jawaban benar soal ${si + 1} modul ${i + 1} opsi ${
                                    oi + 1
                                  }`}
                                  checked={s.kunci === oi}
                                  onChange={() => aturSoal(i, si, { kunci: oi })}
                                />
                                <input
                                  type="text"
                                  aria-label={`Opsi ${oi + 1} soal ${si + 1} modul ${i + 1}`}
                                  placeholder={`Opsi ${oi + 1}`}
                                  maxLength={200}
                                  className={inputCls}
                                  value={o}
                                  onChange={(event) => aturOpsi(i, si, oi, event.target.value)}
                                />
                                {s.opsi.length > 2 && (
                                  <button
                                    type="button"
                                    aria-label={`Hapus opsi ${oi + 1} soal ${si + 1}`}
                                    onClick={() => hapusOpsi(i, si, oi)}
                                    className="text-xs font-semibold text-red-700 hover:underline"
                                  >
                                    ✕
                                  </button>
                                )}
                              </li>
                            ))}
                          </ul>
                          {s.opsi.length < 6 && (
                            <button
                              type="button"
                              onClick={() => tambahOpsi(i, si)}
                              className="mt-1 text-xs font-semibold text-brand hover:underline"
                            >
                              + Tambah opsi
                            </button>
                          )}
                        </li>
                      ))}
                    </ol>
                    {(m.quiz ?? []).length < 10 && (
                      <button
                        type="button"
                        onClick={() => tambahSoal(i)}
                        className="mt-2 rounded border border-line px-3 py-1 text-xs font-semibold hover:bg-soft"
                      >
                        + Tambah soal
                      </button>
                    )}
                  </div>
                  </details>
                  {modul.length > 1 && (
                    <button
                      type="button"
                      onClick={() => setModul((prev) => prev.filter((_, j) => j !== i))}
                      className="mt-2 text-sm font-semibold text-red-700 hover:underline"
                    >
                      Hapus modul ini
                    </button>
                  )}
                </li>
              ))}
            </ol>
            <button
              type="button"
              onClick={() => setModul((prev) => [...prev, { ...MODUL_KOSONG }])}
              className="mt-2 rounded-lg border border-line px-4 py-2 text-sm font-semibold hover:bg-soft"
            >
              + Tambah modul
            </button>
          </BagianForm>
          <div className="flex gap-2">
            <button
              type="submit"
              className="rounded-lg bg-brand px-5 py-2 font-semibold text-white hover:opacity-90"
            >
              Simpan
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('daftar');
                setKodeEdit(null);
                setPesan(null);
              }}
              className="rounded-lg border border-line px-5 py-2 font-semibold hover:bg-soft"
            >
              Batal
            </button>
          </div>
        </form>
      )}
    </section>
  );
}

/**
 * Section CRUD anggota tim (tab "Tim", Prioritas 2). Kunci baris = `id` dari
 * backend (GET /api/tim mengembalikan id & urutan); foto diperlakukan seperti
 * gambar lain — file diunggah saat Simpan, URL hasilnya masuk ke body.
 */
function TimAdmin({ token, gagal401 }: { token: string; gagal401: () => void }) {
  const [daftar, setDaftar] = useState<AnggotaTim[]>([]);
  const [mode, setMode] = useState<'daftar' | 'tambah' | 'ubah'>('daftar');
  const [idEdit, setIdEdit] = useState<number | null>(null);
  const [f, setF] = useState({ nama: '', peran: '', kredensial: '', foto: '', urutan: '0' });
  const [fileFoto, setFileFoto] = useState<File | null>(null);
  const [pratinjau, setPratinjau] = useState<string | null>(null);
  const [pesan, setPesan] = useState<{ teks: string; sukses: boolean } | null>(null);

  async function muat(): Promise<void> {
    setDaftar(await ambilDaftar<AnggotaTim>('/tim', []));
  }

  useEffect(() => {
    void muat();
    // muatDaftar stabil (closure tanpa state); muat sekali saat mount.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function tanganiError(error: unknown): void {
    if ((error as { status?: number } | null)?.status === 401) {
      gagal401();
      return;
    }
    setPesan({
      teks: error instanceof Error ? error.message : 'Terjadi kesalahan yang tidak dikenal',
      sukses: false,
    });
  }

  /** URL object untuk pratinjau file baru di-revoke saat berganti/batal. */
  function lepasPratinjau(): void {
    if (pratinjau !== null && pratinjau.startsWith('blob:')) URL.revokeObjectURL(pratinjau);
  }

  function mulaiTambah(): void {
    // Urutan tidak diisi manual — item baru otomatis paling atas (server paksa 0).
    setF({ nama: '', peran: '', kredensial: '', foto: '', urutan: '0' });
    setFileFoto(null);
    setPratinjau(null);
    setMode('tambah');
    setPesan(null);
  }

  function mulaiUbah(item: AnggotaTim): void {
    if (item.id === undefined) return;
    setF({
      nama: item.nama,
      peran: item.peran,
      kredensial: item.kredensial ?? '',
      foto: item.foto ?? '',
      urutan: String(item.urutan ?? 0),
    });
    setFileFoto(null);
    setPratinjau(null);
    setIdEdit(item.id);
    setMode('ubah');
    setPesan(null);
  }

  function pilihFoto(event: ChangeEvent<HTMLInputElement>): void {
    const file = event.target.files?.[0] ?? null;
    lepasPratinjau();
    setFileFoto(file);
    setPratinjau(file !== null ? URL.createObjectURL(file) : null);
  }

  function batalkan(): void {
    lepasPratinjau();
    setMode('daftar');
    setIdEdit(null);
    setFileFoto(null);
    setPratinjau(null);
    setPesan(null);
  }

  async function simpan(event: FormEvent): Promise<void> {
    event.preventDefault();
    setPesan(null);
    try {
      let foto = f.foto;
      if (fileFoto !== null) {
        const unggah = await kirimFileAdmin('/admin/upload', fileFoto, { token });
        foto = unggah.url;
      }
      const body = {
        nama: f.nama,
        peran: f.peran,
        kredensial: f.kredensial,
        foto,
        urutan: Number(f.urutan),
      };
      const ubah = mode === 'ubah' && idEdit !== null;
      const hasil = await kirimJsonAdmin<AnggotaTim>(ubah ? `/tim/${idEdit}` : '/tim', {
        method: ubah ? 'PUT' : 'POST',
        body,
        token,
      });
      setPesan({
        teks: ubah ? `Anggota "${hasil.nama}" diperbarui.` : `Anggota "${hasil.nama}" tersimpan.`,
        sukses: true,
      });
      setMode('daftar');
      setIdEdit(null);
      setFileFoto(null);
      lepasPratinjau();
      setPratinjau(null);
      await muat();
    } catch (error) {
      tanganiError(error);
    }
  }

  async function hapus(item: AnggotaTim): Promise<void> {
    if (item.id === undefined) return;
    const yakin = window.confirm(
      `Hapus "${item.nama}" dari tim? Tindakan ini tidak bisa dibatalkan.`,
    );
    if (!yakin) return;
    setPesan(null);
    try {
      await kirimJsonAdmin(`/tim/${item.id}`, { method: 'DELETE', token });
      setPesan({ teks: `Anggota "${item.nama}" dihapus.`, sukses: true });
      await muat();
    } catch (error) {
      tanganiError(error);
    }
  }

  const elemenPesan =
    pesan === null ? null : (
      <p
        role={pesan.sukses ? 'status' : 'alert'}
        className={`mt-4 rounded-lg px-4 py-3 text-sm ${
          pesan.sukses ? 'bg-soft text-emerald-800' : 'bg-red-50 text-red-800'
        }`}
      >
        {pesan.teks}
      </p>
    );

  const inputCls = 'mt-1 w-full rounded-lg border border-line px-3 py-2';
  const labelCls = 'block text-sm font-semibold';

  return (
    <section className="mt-6">
      <div className="flex items-center justify-between gap-3">
        <h2 className="font-display text-xl font-bold">Tim</h2>
        {mode === 'daftar' && (
          <button
            type="button"
            onClick={mulaiTambah}
            className="rounded-lg bg-brand px-4 py-2 text-sm font-semibold text-white hover:opacity-90"
          >
            + Tambah baru
          </button>
        )}
      </div>

      {elemenPesan}

      {mode === 'daftar' ? (
        daftar.length === 0 ? (
          <p className="mt-4 text-sm text-muted">Belum ada anggota Tim.</p>
        ) : (
          <ul className="mt-4 divide-y divide-line rounded-xl border border-line">
            {daftar.map((item, i) => (
              <li key={item.id ?? i} className="flex items-center gap-3 px-4 py-3">
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold">{item.nama}</p>
                  <p className="text-xs text-muted">
                    {item.peran}
                    {item.kredensial !== undefined ? ` · ${item.kredensial}` : ''} · urutan{' '}
                    {item.urutan ?? '-'}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => mulaiUbah(item)}
                  className="rounded-lg border border-line px-3 py-1.5 text-sm font-semibold hover:bg-soft"
                >
                  Ubah
                </button>
                <button
                  type="button"
                  onClick={() => void hapus(item)}
                  className="rounded-lg border border-red-200 px-3 py-1.5 text-sm font-semibold text-red-700 hover:bg-red-50"
                >
                  Hapus
                </button>
              </li>
            ))}
          </ul>
        )
      ) : (
        <form onSubmit={simpan} className="mt-4 space-y-4 rounded-xl border border-line p-5">
          <h3 className="font-semibold">
            {mode === 'ubah' ? `Ubah anggota — ${f.nama}` : 'Tambah anggota baru'}
          </h3>
          <div>
            <label htmlFor="tim-nama" className={labelCls}>
              Nama *
            </label>
            <input
              id="tim-nama"
              type="text"
              required
              maxLength={200}
              className={inputCls}
              value={f.nama}
              onChange={(event) => setF((prev) => ({ ...prev, nama: event.target.value }))}
            />
          </div>
          <div>
            <label htmlFor="tim-peran" className={labelCls}>
              Peran *
            </label>
            <input
              id="tim-peran"
              type="text"
              required
              maxLength={200}
              className={inputCls}
              value={f.peran}
              onChange={(event) => setF((prev) => ({ ...prev, peran: event.target.value }))}
            />
          </div>
          <div>
            <label htmlFor="tim-kredensial" className={labelCls}>
              Kredensial (opsional)
            </label>
            <input
              id="tim-kredensial"
              type="text"
              maxLength={300}
              className={inputCls}
              value={f.kredensial}
              onChange={(event) => setF((prev) => ({ ...prev, kredensial: event.target.value }))}
            />
          </div>
          {/* Urutan hanya bisa diatur manual saat Ubah — saat Tambahan baru
              item otomatis jadi paling atas (server menggeser baris lama +1). */}
          {mode === 'ubah' && (
            <div>
              <label htmlFor="tim-urutan" className={labelCls}>
                Urutan tampil (0 = paling atas) *
              </label>
              <input
                id="tim-urutan"
                type="number"
                required
                min={0}
                max={9999}
                className={inputCls}
                value={f.urutan}
                onChange={(event) => setF((prev) => ({ ...prev, urutan: event.target.value }))}
              />
            </div>
          )}
          <div>
            <label htmlFor="tim-foto" className={labelCls}>
              Foto (file JPG/PNG/WebP, maks 2 MB)
            </label>
            <input
              id="tim-foto"
              type="file"
              accept="image/jpeg,image/png,image/webp"
              className="mt-1 block text-sm"
              onChange={pilihFoto}
            />
            {pratinjau !== null && (
              <img
                src={pratinjau}
                alt="Pratinjau foto anggota"
                className="mt-2 h-24 w-24 rounded-full object-cover"
              />
            )}
            {mode === 'ubah' && f.foto !== '' && fileFoto === null && pratinjau === null && (
              <p className="mt-1 text-xs text-muted">
                Foto saat ini: {f.foto} — pilih file baru untuk mengganti.
              </p>
            )}
          </div>
          <div className="flex gap-2">
            <button
              type="submit"
              className="rounded-lg bg-brand px-5 py-2 font-semibold text-white hover:opacity-90"
            >
              Simpan
            </button>
            <button
              type="button"
              onClick={batalkan}
              className="rounded-lg border border-line px-5 py-2 font-semibold hover:bg-soft"
            >
              Batal
            </button>
          </div>
        </form>
      )}
    </section>
  );
}

/**
 * Section CRUD testimoni (tab "Testimoni" — lengkapi CRUD admin, pola sama
 * dengan TimAdmin). Kunci baris = `id` dari backend; GET /api/testimoni
 * mengembalikan `id` & `urutan` (data dummy tidak memilikinya).
 */
function TestimoniAdmin({ token, gagal401 }: { token: string; gagal401: () => void }) {
  const [daftar, setDaftar] = useState<Testimoni[]>([]);
  const [mode, setMode] = useState<'daftar' | 'tambah' | 'ubah'>('daftar');
  const [idEdit, setIdEdit] = useState<number | null>(null);
  const [f, setF] = useState({ nama: '', peran: '', kutipan: '', urutan: '0' });
  const [pesan, setPesan] = useState<{ teks: string; sukses: boolean } | null>(null);

  async function muat(): Promise<void> {
    setDaftar(await ambilDaftar<Testimoni>('/testimoni', []));
  }

  useEffect(() => {
    void muat();
    // muat stabil (closure tanpa state); muat sekali saat mount.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function tanganiError(error: unknown): void {
    if ((error as { status?: number } | null)?.status === 401) {
      gagal401();
      return;
    }
    setPesan({
      teks: error instanceof Error ? error.message : 'Terjadi kesalahan yang tidak dikenal',
      sukses: false,
    });
  }

  function mulaiTambah(): void {
    // Urutan tidak diisi manual — testimoni baru otomatis jadi #1 (server paksa 0).
    setF({ nama: '', peran: '', kutipan: '', urutan: '0' });
    setMode('tambah');
    setPesan(null);
  }

  function mulaiUbah(item: Testimoni): void {
    if (item.id === undefined) return;
    setF({
      nama: item.nama,
      peran: item.peran,
      kutipan: item.kutipan,
      urutan: String(item.urutan ?? 0),
    });
    setIdEdit(item.id);
    setMode('ubah');
    setPesan(null);
  }

  function batalkan(): void {
    setMode('daftar');
    setIdEdit(null);
    setPesan(null);
  }

  async function simpan(event: FormEvent): Promise<void> {
    event.preventDefault();
    setPesan(null);
    try {
      const body = {
        nama: f.nama,
        peran: f.peran,
        kutipan: f.kutipan,
        urutan: Number(f.urutan),
      };
      const ubah = mode === 'ubah' && idEdit !== null;
      const hasil = await kirimJsonAdmin<Testimoni>(ubah ? `/testimoni/${idEdit}` : '/testimoni', {
        method: ubah ? 'PUT' : 'POST',
        body,
        token,
      });
      setPesan({
        teks: ubah
          ? `Testimoni "${hasil.nama}" diperbarui.`
          : `Testimoni "${hasil.nama}" tersimpan.`,
        sukses: true,
      });
      setMode('daftar');
      setIdEdit(null);
      await muat();
    } catch (error) {
      tanganiError(error);
    }
  }

  async function hapus(item: Testimoni): Promise<void> {
    if (item.id === undefined) return;
    const yakin = window.confirm(
      `Hapus testimoni "${item.nama}"? Tindakan ini tidak bisa dibatalkan.`,
    );
    if (!yakin) return;
    setPesan(null);
    try {
      await kirimJsonAdmin(`/testimoni/${item.id}`, { method: 'DELETE', token });
      setPesan({ teks: `Testimoni "${item.nama}" dihapus.`, sukses: true });
      await muat();
    } catch (error) {
      tanganiError(error);
    }
  }

  const elemenPesan =
    pesan === null ? null : (
      <p
        role={pesan.sukses ? 'status' : 'alert'}
        className={`mt-4 rounded-lg px-4 py-3 text-sm ${
          pesan.sukses ? 'bg-soft text-emerald-800' : 'bg-red-50 text-red-800'
        }`}
      >
        {pesan.teks}
      </p>
    );

  const inputCls = 'mt-1 w-full rounded-lg border border-line px-3 py-2';
  const labelCls = 'block text-sm font-semibold';

  return (
    <section className="mt-6">
      <div className="flex items-center justify-between gap-3">
        <h2 className="font-display text-xl font-bold">Testimoni</h2>
        {mode === 'daftar' && (
          <button
            type="button"
            onClick={mulaiTambah}
            className="rounded-lg bg-brand px-4 py-2 text-sm font-semibold text-white hover:opacity-90"
          >
            + Tambah baru
          </button>
        )}
      </div>

      {elemenPesan}

      {mode === 'daftar' ? (
        daftar.length === 0 ? (
          <p className="mt-4 text-sm text-muted">Belum ada testimoni.</p>
        ) : (
          <ul className="mt-4 divide-y divide-line rounded-xl border border-line">
            {daftar.map((item, i) => (
              <li key={item.id ?? i} className="flex items-start gap-3 px-4 py-3">
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold">{item.nama}</p>
                  <p className="text-xs text-muted">
                    {item.peran} · urutan {item.urutan ?? '-'}
                  </p>
                  <p className="mt-1 line-clamp-2 text-xs text-muted">{item.kutipan}</p>
                </div>
                <button
                  type="button"
                  onClick={() => mulaiUbah(item)}
                  className="rounded-lg border border-line px-3 py-1.5 text-sm font-semibold hover:bg-soft"
                >
                  Ubah
                </button>
                <button
                  type="button"
                  onClick={() => void hapus(item)}
                  className="rounded-lg border border-red-200 px-3 py-1.5 text-sm font-semibold text-red-700 hover:bg-red-50"
                >
                  Hapus
                </button>
              </li>
            ))}
          </ul>
        )
      ) : (
        <form onSubmit={simpan} className="mt-4 space-y-4 rounded-xl border border-line p-5">
          <h3 className="font-semibold">
            {mode === 'ubah' ? `Ubah testimoni — ${f.nama}` : 'Tambah testimoni baru'}
          </h3>
          <div>
            <label htmlFor="testimoni-nama" className={labelCls}>
              Nama *
            </label>
            <input
              id="testimoni-nama"
              type="text"
              required
              maxLength={200}
              className={inputCls}
              value={f.nama}
              onChange={(event) => setF((prev) => ({ ...prev, nama: event.target.value }))}
            />
          </div>
          <div>
            <label htmlFor="testimoni-peran" className={labelCls}>
              Peran (mis. Mahasiswa) *
            </label>
            <input
              id="testimoni-peran"
              type="text"
              required
              maxLength={200}
              className={inputCls}
              value={f.peran}
              onChange={(event) => setF((prev) => ({ ...prev, peran: event.target.value }))}
            />
          </div>
          <div>
            <label htmlFor="testimoni-kutipan" className={labelCls}>
              Kutipan *
            </label>
            <textarea
              id="testimoni-kutipan"
              required
              rows={3}
              maxLength={1000}
              className={inputCls}
              value={f.kutipan}
              onChange={(event) => setF((prev) => ({ ...prev, kutipan: event.target.value }))}
            />
          </div>
          {/* Urutan hanya bisa diatur manual saat Ubah — saat tambah baru
              testimoni otomatis jadi #1 (server menggeser baris lama +1). */}
          {mode === 'ubah' && (
            <div>
              <label htmlFor="testimoni-urutan" className={labelCls}>
                Urutan tampil (0 = paling atas) *
              </label>
              <input
                id="testimoni-urutan"
                type="number"
                required
                min={0}
                max={9999}
                className={inputCls}
                value={f.urutan}
                onChange={(event) => setF((prev) => ({ ...prev, urutan: event.target.value }))}
              />
            </div>
          )}
          <div className="flex gap-2">
            <button
              type="submit"
              className="rounded-lg bg-brand px-5 py-2 font-semibold text-white hover:opacity-90"
            >
              Simpan
            </button>
            <button
              type="button"
              onClick={batalkan}
              className="rounded-lg border border-line px-5 py-2 font-semibold hover:bg-soft"
            >
              Batal
            </button>
          </div>
        </form>
      )}
    </section>
  );
}

