import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';

// Dibaca dari disk karena ini unit CSS (sumber kebenaran token design).
const css = readFileSync(join(process.cwd(), 'src', 'index.css'), 'utf8');

/** Ambil nilai token dari @theme, mis. --color-brand → #3a31e5 */
function token(name: string): string {
  const m = css.match(new RegExp(`${name}:\\s*([^;]+);`));
  if (!m) throw new Error(`Token ${name} tidak ditemukan di src/index.css`);
  return m[1].trim();
}

/** WCAG relative luminance (helper khusus test). */
function luminance(hex: string): number {
  const n = hex.replace('#', '');
  const [r, g, b] = [0, 2, 4].map((i) => {
    const ch = parseInt(n.slice(i, i + 2), 16) / 255;
    return ch <= 0.04045 ? ch / 12.92 : ((ch + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

/** WCAG contrast ratio 1..21 (helper khusus test). */
function contrast(a: string, b: string): number {
  const [l1, l2] = [luminance(a), luminance(b)].sort((x, y) => y - x);
  return (l1 + 0.05) / (l2 + 0.05);
}

describe('Token identitas visual (src/index.css @theme)', () => {
  it('palet primer persis sesuai daftar warna dari Figma', () => {
    expect(token('--color-brand')).toBe('#2547F4'); // biru royal
    expect(token('--color-brand-bright')).toBe('#0674FD'); // biru terang
    expect(token('--color-navy')).toBe('#0A2240'); // navy surface gelap
    expect(token('--color-ink')).toBe('#0A2240'); // teks utama (peran teks)
    expect(token('--color-soft')).toBe('#FAF7F0'); // krem section
    expect(token('--color-sky')).toBe('#D8EBF8'); // biru muda section
  });

  it('warna pelengkap tersedia sebagai token aksen', () => {
    expect(token('--color-mint')).toBe('#3CFBC5');
    expect(token('--color-yellow')).toBe('#F3D502');
    expect(token('--color-teal')).toBe('#0C7C6C');
    expect(token('--color-orange')).toBe('#FF6B2C');
  });

  it('font identitas: Cabinet Grotesk (judul) + General Sans (isi) + Geist Mono (teknis)', () => {
    expect(token('--font-display')).toContain('Cabinet Grotesk');
    expect(token('--font-display')).toContain('Helvetica Neue'); // fallback sistem
    expect(token('--font-body')).toContain('General Sans');
    expect(token('--font-mono')).toContain('Geist Mono');
    expect(token('--font-mono')).toContain('monospace'); // fallback sistem
    expect(css).toContain('Geist Mono');
  });

  it('@font-face memuat file lokal: isi bobot 400–700 & judul 700–800', () => {
    expect(css).toContain("url('/fonts/GeneralSans-Regular.woff2')");
    expect(css).toContain("url('/fonts/GeneralSans-Medium.woff2')");
    expect(css).toContain("url('/fonts/GeneralSans-SemiBold.woff2')");
    expect(css).toContain("url('/fonts/GeneralSans-Bold.woff2')");
    expect(css).toContain("url('/fonts/CabinetGrotesk-Bold.woff2')");
    expect(css).toContain("url('/fonts/CabinetGrotesk-ExtraBold.woff2')");
    expect(css).not.toContain('fontshare.com'); // self-host, bukan CDN
  });

  it('Geist Mono: file variabel menutup bobot 400–900 (bold sungguhan, bukan sintesis)', () => {
    expect(css).toContain("url('/fonts/GeistMono-Variable.woff2')");
    // Deklarasi rentang → `font-mono font-bold` di-instance 700 oleh browser;
    // kalau hanya 400, kicker/tag jadi bold palsu (sintesis browser).
    expect(css).toMatch(
      /font-family: 'Geist Mono'[\s\S]{0,400}?font-weight:\s*100 900\s*;/,
    );
    expect(css).not.toContain('GeistMono-Regular.woff2'); // file lama (statis 400) diganti
  });

  it('semua file font yang dirujuk index.css benar-benar ada di public/fonts', () => {
    const rujukan = [...css.matchAll(/url\('\/fonts\/([^']+\.woff2)'\)/g)].map((m) => m[1]);
    expect(rujukan.length).toBeGreaterThanOrEqual(7);
    for (const nama of rujukan) {
      expect(() =>
        readFileSync(join(process.cwd(), 'public', 'fonts', nama)),
      ).not.toThrow();
    }
  });

  it('footer gelap dipertahankan font lamanya (Helvetica) sementara', () => {
    expect(css).toMatch(/\.footer-legacy-font\s*\{[^}]*Helvetica/);
  });

  it('token turunan surface: putih dihangatkan agar kartu menyatu dengan section krem', () => {
    expect(token('--color-surface')).toBe('#FCFBF7');
    // Nyaris sama dengan krem → kontras kartu vs section rendah ("lebih menyatu")
    expect(contrast(token('--color-surface'), token('--color-soft'))).toBeLessThan(1.1);
  });
});

describe('Kontras WCAG AA pasangan warna kunci', () => {
  const white = '#ffffff';

  it('teks di atas background terang', () => {
    expect(contrast(token('--color-ink'), white)).toBeGreaterThanOrEqual(7);
    expect(contrast(token('--color-muted'), white)).toBeGreaterThanOrEqual(4.5);
    expect(contrast(token('--color-muted'), token('--color-soft'))).toBeGreaterThanOrEqual(4.5);
  });

  it('brand sebagai teks (link/kicker) di putih dan di section bg-soft', () => {
    expect(contrast(token('--color-brand'), white)).toBeGreaterThanOrEqual(4.5);
    expect(contrast(token('--color-brand'), token('--color-soft'))).toBeGreaterThanOrEqual(4.5);
  });

  it('teks putih di atas brand & navy (tombol, section dokumentasi, footer)', () => {
    // Ujung gradient tombol = brand → navy; keduanya wajib aman untuk teks putih
    expect(contrast(white, token('--color-brand'))).toBeGreaterThanOrEqual(4.5);
    expect(contrast(white, token('--color-navy'))).toBeGreaterThanOrEqual(4.5);
  });
});

describe('Gradient tombol utama (.btn-primary)', () => {
  it('memakai gradient 135deg brand → navy (dua ujung aman kontras untuk teks putih)', () => {
    expect(css).toMatch(/\.btn-primary\s*\{[^}]*linear-gradient\(135deg, var\(--color-brand\)/);
    expect(css).toMatch(/var\(--color-navy\)/);
    // hover/active memberi umpan balik → filter brightness
    expect(css).toMatch(/\.btn-primary:hover\s*\{[^}]*brightness/);
  });

  it('hover terasa: tombol terangkat + bayangan (bukan cuma brightness)', () => {
    expect(css).toMatch(/\.btn-primary:hover\s*\{[^}]*translateY\(-2px\)/);
    expect(css).toMatch(/\.btn-primary:hover\s*\{[^}]*box-shadow/);
  });
});

describe('Tombol aksen konversi (.btn-accent, CTA berani)', () => {
  it('oranye solid + teks navy (bukan teks putih yang gagal kontras)', () => {
    expect(css).toMatch(/\.btn-accent\s*\{[^}]*background-color: var\(--color-orange\)/);
    expect(css).toMatch(/\.btn-accent\s*\{[^}]*color: var\(--color-navy\)/);
    expect(css).toMatch(/\.btn-accent:hover\s*\{[^}]*brightness/);
  });

  it('kontras teks navy di atas oranye ≥ 4.5 (WCAG AA)', () => {
    expect(contrast(token('--color-navy'), token('--color-orange'))).toBeGreaterThanOrEqual(4.5);
  });

  it('hover terasa: tombol terangkat + bayangan (bukan cuma brightness)', () => {
    expect(css).toMatch(/\.btn-accent:hover\s*\{[^}]*translateY\(-2px\)/);
    expect(css).toMatch(/\.btn-accent:hover\s*\{[^}]*box-shadow/);
  });

  it('konsisten: SEMUA tombol lain ikut terangkat + berbayang saat hover', () => {
    expect(css).toMatch(
      /button:not\(:disabled\):not\(\.btn-primary\):not\(\.btn-accent\):hover\s*\{[^}]*translateY\(-2px\)/,
    );
    expect(css).toMatch(
      /button:not\(:disabled\):not\(\.btn-primary\):not\(\.btn-accent\):hover\s*\{[^}]*box-shadow/,
    );
  });
});

describe('Garis aksen kartu (.card-accent, pola situs patokan)', () => {
  it('gradient 90deg brand → bright yang muncul saat hover/fokus', () => {
    expect(css).toMatch(/\.card-accent::after\s*\{[^}]*linear-gradient\(90deg, var\(--color-brand\)/);
    expect(css).toMatch(/var\(--color-brand-bright\)/);
    expect(css).toMatch(/\.card-accent:hover::after/);
    expect(css).toMatch(/\.card-accent:focus-within::after/);
  });

  it('hover-lift eksplisit (transform + box-shadow) + mati saat reduced-motion', () => {
    expect(css).toMatch(/\.card-accent\s*\{[^}]*transition: transform 200ms ease, box-shadow 200ms ease/);
    expect(css).toMatch(/\.card-accent:hover\s*\{[^}]*translateY\(-6px\)/);
    expect(css).toMatch(/@media \(prefers-reduced-motion: reduce\)/);
    expect(css).not.toMatch(/transition:\s*all/);
  });
});

describe('Navigasi device-aware (mobile = burger, desktop = navbar)', () => {
  it('memakai custom variant fine-pointer untuk membedakan desktop vs layar sentuh', () => {
    expect(css).toContain('@custom-variant fine-pointer (@media (pointer: fine))');
  });
});

describe('Turunan warna di atas navy (PROGRESS 4 — di luar daftar Figma, kini token)', () => {
  it('nilai token persis sama dengan hex lama di komponen (tampilan tidak berubah)', () => {
    expect(token('--color-onnavy')).toBe('#dbe3ff'); // kicker/sub section navy
    expect(token('--color-onnavy-badge')).toBe('#ccd7ff'); // kicker badge hero
    expect(token('--color-onnavy-body')).toBe('#e8eaf6'); // paragraf sub hero
    expect(token('--color-onnavy-soft')).toBe('#c9cde6'); // teks isi footer
    expect(token('--color-onnavy-dim')).toBe('#9aa0c7'); // copyright footer
  });

  it('tiap turunan tetap lolos kontras WCAG AA (4.5:1) di atas navy', () => {
    const navy = token('--color-navy');
    for (const nama of [
      '--color-onnavy',
      '--color-onnavy-badge',
      '--color-onnavy-body',
      '--color-onnavy-soft',
      '--color-onnavy-dim',
    ]) {
      expect(contrast(token(nama), navy)).toBeGreaterThanOrEqual(4.5);
    }
  });

  it('tidak ada hex hardcoded di src/**/*.{ts,tsx} — semua warna wajib lewat token @theme', () => {
    /** Rekursif: kumpulkan file .ts/.tsx selain file test. */
    const daftarSumber = (dir: string): string[] =>
      readdirSync(dir, { withFileTypes: true }).flatMap((entri) => {
        const p = join(dir, entri.name);
        if (entri.isDirectory()) return daftarSumber(p);
        const sumber = /\.(ts|tsx)$/.test(entri.name) && !/\.test\.(ts|tsx)$/.test(entri.name);
        return sumber ? [p] : [];
      });
    const pelanggar = daftarSumber(join(process.cwd(), 'src')).filter((f) =>
      /#[0-9a-fA-F]{3,8}\b/.test(readFileSync(f, 'utf8')),
    );
    expect(pelanggar.map((f) => f.replace(process.cwd() + '/', ''))).toEqual([]);
  });
});
