# Web AI Center — Frontend

CMS frontend AI Center Universitas Surabaya. Terhubung ke backend
(`VITE_API_BASE_URL`, lihat `.env.example`) — bila backend mati, env kosong, atau
mode test, semua halaman otomatis memakai data dummy (lihat `src/lib/api.ts`).

## Tech stack

- React 19 + TypeScript + Vite 7 (SPA, React Router v7)
- Tailwind CSS v4 + `motion` (animasi carousel)
- Vitest + Testing Library + jsdom (unit test)
- Node.js ≥ 20

## Halaman

| Rute | Isi |
|---|---|
| `/` → `/beranda` | Hero carousel (2 slide foto), Layanan (2 kartu), highlight Dokumentasi (3 card), Testimoni, highlight Berita (3 card) |
| `/tim` | Daftar tim + pencarian |
| `/tentang-kami` | Profil, alamat |
| `/berita`, `/berita/:slug` | Daftar + pencarian, detail |
| `/dokumentasi`, `/dokumentasi/:slug` | Daftar + pencarian, detail |

## Arti penanda di kode

- `TODO_BACKEND` — bagian yang **sengaja belum diintegrasikan** + alasannya di komentar (menunggu keputusan konten/endpoint/akun). Sebagian besar endpoint sudah terintegrasi lewat `src/lib/useApiData.ts`.
- `TODO_ASSET` — file aset (mis. foto hero) perlu diganti/ditambah di `public/`.
- Limit 3 card hanya di highlight beranda; halaman `/berita` dan `/dokumentasi` me-render semua data tanpa batas.

## File `.test.tsx` / `.test.ts`

Unit test kecil per unit (input → output + 1–2 edge case). Dijalankan via `npm test`. Bukan integration/e2e test.

Catatan keputusan: 53 file test (39 frontend + 14 backend) **sengaja ikut
di-commit** walaupun aturan kerja awal menyebut file test lokal saja — supaya bukti
unit test ikut terlihat di repo untuk laporan KP dan gerbang bisa dijalankan di
mesin lain.

## Folder `lighthouse_report/`

Arsip hasil ukur Lighthouse (JSON mentah). File `prod*-*.json` = hasil build produksi (acuan skor). Ukur ulang selalu terhadap build produksi, bukan dev server.

## Menjalankan di laptop lain

```bash
npm install
npm run dev      # development (http://localhost:5173)
npm test         # unit test
npm run build    # build produksi ke dist/
npm run preview  # sajikan hasil build (http://localhost:4173)
```

Catatan: butuh Node ≥ 20 dan akses internet (instalasi pertama). Nilai asli (API key dsb.) hanya di `.env` lokal — lihat `.env.example`, jangan commit `.env`.

Menjalankan **dengan data dari database**: salin `.env.example` → `.env`, jalankan
backend `server/` (bagian bawah) dulu, baru `npm run dev`. Tanpa `.env`, web tetap
jalan penuh dengan data dummy.

## Deployment (produksi)

Ringkas: **frontend = file statis `dist/`**, **backend = proses Bun + PostgreSQL**.
Keduanya boleh beda domain — `src/lib/gambar.ts` otomatis menempelkan path
`/uploads/…` ke origin backend, jadi gambar unggahan tetap termuat.

### Backend

1. Isi `server/.env` (salin `server/.env.example`) — semua wajib di produksi:
   `DATABASE_URL` (PostgreSQL asli), `CORS_ORIGIN` (origin frontend produksi,
   pisah koma), `ADMIN_PASSWORD` (**jangan** sampai fallback `admin-dev`),
   `PORT`, `UPLOAD_DIR` (folder persistent di luar repo, writable).
2. ```bash
   cd server
   bun install            # lockfile: server/bun.lock
   bun run db:migrate     # migrasi SQL ke DB produksi
   bun run db:seed        # sekali saja — konten awal (idempoten)
   bun run start          # tanpa watch; jalankan di balik systemd/PM2/nginx
   ```
3. Verifikasi: `GET <api>/api/health` → `{"status":"ok","db":"ok"}`, lalu uji
   login `POST /api/admin/login`.
4. Backup: folder `UPLOAD_DIR` + database secara terpisah. Token admin berlaku
   6 jam (di memori proses); login di-rate-limit 5 gagal / 10 menit per IP.

### Frontend

1. Isi `.env` root **sebelum build** (nilainya di-bake ke `dist/`):
   `VITE_API_BASE_URL=https://<api-domain>/api` — kosongkan bila ingin situs
   berjalan murni dengan data dummy.
2. ```bash
   npm install
   npm test && npx tsc -b --noEmit   # gerbang wajib lulus dulu
   npm run build                     # hasil ke dist/
   ```
3. Salin isi `dist/` ke web server statis. **Path dasar** saat ini
   `/coding/Web-AI-Center/` (konstanta `BASE` di `vite.config.ts`) — bila deploy
   di root/subfolder lain, ubah `BASE` **dan** path preload hero di `index.html`
   (`l.href` + `imagesrcset`), lalu build ulang. Untuk rute SPA di Nginx: tambah
   fallback `try_files $uri /coding/Web-AI-Center/index.html`.
4. Setelah domain fix: isi `VITE_SITE_URL`, daftarkan sitemap di
   `public/robots.txt`, ukur ulang Lighthouse terhadap build hasil deploy.

Catatan: CORS backend **hanya** menerima origin terdaftar di `CORS_ORIGIN` — lupa
mengisi membuat fetch frontend ditolak (halaman tetap tampil, tapi dengan data
dummy, jadi gampang tidak ketahuan; cek tab Network saat verifikasi).

### Checklist sebelum final

- [ ] Gerbang: `npm test` → `npx tsc -b --noEmit` → `npm run build`; di `server/`:
      `bun run typecheck` + `bun test`
- [ ] Lighthouse terhadap build produksi (`npm run preview`) — semua skor ≥ 90
- [ ] Backend sehat: `GET :3000/api/health` → `{"status":"ok","db":"ok"}`
- [ ] Demo: `http://localhost:5173/coding/Web-AI-Center/beranda` + login `/admin`
      memakai `ADMIN_PASSWORD` dari `server/.env`
- [ ] Repo bersih: `git status -sb` tidak ada perubahan menggantung

## Backend `server/` (baru)

API **baca publik + tulis admin** — Bun + Elysia + Drizzle ORM + PostgreSQL. Dev
lokal tidak butuh
instalasi Postgres: kosongkan `DATABASE_URL` → otomatis memakai **PGlite**
(Postgres in-process, data di `server/.pglite/`, di-gitignore). Isi `.env` dari
`server/.env.example` untuk koneksi PostgreSQL asli (nilai dummy saja di sana).

```bash
cd server
bun install
bun run db:migrate      # jalankan migrasi SQL (drizzle/)
bun run db:seed         # isi data dummy (idempoten)
bun run dev             # http://localhost:3000/api/health (watch)
bun test                # unit test backend (bun:test)
bun run typecheck       # tsc --noEmit
bun run db:generate     # generate migrasi — hanya setelah ubah schema.ts
```

Cakupan test backend: 14 dari 15 unit logika punya `*.test.ts` di sebelah file
yang diuji. Pengecualian sadar: `server/src/repositories/drizzle.ts` (lapisan SQL)
— mengujinya butuh database, sementara aturan kerja melarang test integration;
lapisan ini diverifikasi lewat E2E manual tiap putaran (curl + browser), sedangkan
kontrak di atasnya diuji dengan fake repository (`app.test.ts`) plus
`schema`/`mappers`/`seed` yang punya test sendiri.

### Endpoint

| Endpoint | Query | Catatan |
|---|---|---|
| `GET /api/health` | — | `{ status: "ok" }` |
| `GET /api/berita` | `q`, `page`, `limit`, `order` | `{ items }`; highlight beranda: `?limit=3` |
| `GET /api/berita/:slug` | — | 404 `{ error }` bila tidak ada |
| `GET /api/dokumentasi` | `q`, `kategori`, `page`, `limit`, `order` | `{ items }` |
| `GET /api/dokumentasi/:slug` | — | 404 `{ error }` |
| `GET /api/tim` | `q`, `page`, `limit` | `{ items }` |
| `GET /api/layanan` · `/:slug` | — | `{ items }` / 404 — tak dipakai FE (konten statis `src/data/layanan.ts`) |
| `GET /api/kursus` · `/api/kursus/:kode` | `q`, `page`, `limit` | `{ items }` / 404; kode case-insensitive (`r01`) |
| `GET /api/progress` | `pesertaId` (wajib), `kode` | **publik tanpa akun** — `{ items }` progres milik 1 peserta; `pesertaId` (8–64 `[A-Za-z0-9-]`) / `kode` tidak sah → 400 |
| `POST /api/progress` | body `{ pesertaId, kode, state }` | **publik tanpa akun** — UPSERT per (peserta, kode); `state` objek JSON ≤ 32 KB; rate-limit 60 tulis/menit/IP → 429 + `Retry-After` |
| `GET /api/hero-slides` · `/api/klien` · `/api/testimoni` | — | `{ items }` (hero-slides tak dipakai FE — statis `src/data/hero.ts`) |
| `GET /api/profil` | — | tak dipakai FE (visi/misi statis `src/data/profil.ts`); 404 bila belum di-seed |
| `GET /api/inference` | — | tak dipakai FE (statis `src/data/inference.ts`); 404 bila belum di-seed |
| `POST /api/admin/login` | body `{ password }` | rate-limit 5 gagal / 10 menit per IP → 429; balikan `{ token }` |
| `POST` · `PUT` · `DELETE /api/dokumentasi[/:slug]` | — | butuh `Authorization: Bearer <token>`; 400/404/409 eksplisit |
| `POST` · `PUT` · `DELETE /api/berita[/:slug]` | — | idem; slug dibuat server dari judul |
| `POST` · `PUT` · `DELETE /api/kursus[/:kode]` | — | idem; `kode` jadi kunci unik; tiap item `modul` boleh bawa `video` (URL http(s) ≤ 300) & `quiz` (≤ 10 soal × 2–6 opsi, `kunci` = index opsi) |
| `POST` · `PUT` · `DELETE /api/layanan[/:slug]` | — | idem; slug dibuat server dari nama; `fitur` 1–15 item — tak dipakai FE (tab Layanan dihapus) |
| `PUT /api/profil` | — | profil baris tunggal (id = 1); kolom `statistik` dipertahankan — tak dipakai FE (tab Profil dihapus) |
| `PUT /api/inference` | — | konten halaman inference (id = 1); wajib ≥1 item tiap daftar — tak dipakai FE (tab Inference dihapus) |
| `POST` · `PUT` · `DELETE /api/tim[/:id]` | — | kunci `id` numerik; **POST**: `urutan` diabaikan → semua baris lama digeser +1 lalu item baru disimpan `urutan: 0` (selalu paling atas; tak ada yang dihapus); PUT tetap menerima `urutan` manual |
| `POST` · `PUT` · `DELETE /api/testimoni[/:id]` | — | idem (tab Testimoni di `/admin`); `kutipan` ≤ 1000; **POST** idem: testimoni baru selalu jadi #1 (`urutan: 0`), yang lama turun |
| `POST` · `PUT` · `DELETE /api/hero-slides[/:id]` | — | idem; `layout` hanya `default`/`image-left`/`teks-kanan` — tak dipakai FE (tab Hero dihapus) |
| `POST /api/admin/upload` | multipart `gambar` | file ≤ 2 MB (jpg/png/webp) → `{ url }` `/uploads/<nama>` |
| `POST /api/admin/uploads/bersihkan` | `{ kering? }` | hapus file unggahan yang tidak dirujuk kolom manapun (gambar tidak terpakai); `kering: true` = mode uji |

Semua field teks punya batas panjang di `server/src/lib/tulis.ts` (Prioritas 2) —
body yang lewat batas ditolak 400 dengan pesan menyebut field + batasnya.

CORS: whitelist origin lewat `CORS_ORIGIN` (default `http://localhost:5173`).

### Status integrasi frontend

Terintegrasi lewat `src/lib/useApiData.ts` (`useApiDaftar`/`useApiObjek`) —
setiap halaman selalu punya fallback data di `src/data/` bila `VITE_API_BASE_URL`
kosong, backend mati, respons gagal, atau saat unit test:

- Beranda: testimoni (tepat 3 teratas), highlight berita & dokumentasi
- `/berita` + `/berita/:slug`, `/dokumentasi` + `/:slug`, `/tim`
- katalog kursus + detail (`/api/kursus`, `/api/kursus/:kode`)
- **progres belajar** halaman detail kursus: localStorage tetap sumber utama,
  disinkronkan ke backend **tanpa akun** (`GET`/`POST /api/progress`, identitas =
  `pesertaId` acak di browser) — lihat `src/lib/progresPeserta.ts`; saat keduanya
  punya data: **progres lebih tinggi menang**, seri → jejak belajar lebih banyak,
  seri penuh → lokal (`gabungStateBelajar`)

Konten berikut **sudah bukan bagian dari backend** — sumber satu-satunya ada di
file frontend (diedit via editor kode, bukan lewat `/admin`):

- hero slide → `src/data/hero.ts`, layanan → `src/data/layanan.ts`
- visi/misi profil → `src/data/profil.ts`, konten inference → `src/data/inference.ts`

Kontak footer/WA **sengaja statis** dari situs lama (nomor + pesan persis link
`wa.me` di sana) — lihat `src/data/kontak.ts`.

Masih `TODO_BACKEND` (sadar — menunggu keputusan, bukan lupa):

- konten video & kuis per modul — sistemnya sudah ada (field `modul.video` +
  `modul.quiz` via tab Kursus, embed + kuis di ruang belajar; isi lewat
  template `docs/data-kursus.md`); progres LMS **kini sudah terekam di
  backend** tanpa akun (`/api/progress`, identitas = `pesertaId` per-browser) —
  akun peserta baru dibutuhkan bila ingin sinkron **lintas perangkat**
- section Our Client — endpoint `/api/klien` sudah siap, section dikomentari (rapat)

CRUD admin kini **5 tab**: **dokumentasi**, **berita**, **kursus**, **tim** &
**testimoni** — plus batas panjang semua field teks dan pembersih file gambar
tidak terpakai (`POST /api/admin/uploads/bersihkan` + tombol "Bersihkan gambar
tidak terpakai" di dashboard). Tab **Layanan/Profil/Inference/Hero dihapus**
(Okt 2026): halaman publiknya tetap ada, tapi kontennya jadi **statis frontend**
(`src/data/{hero,layanan,profil,inference}.ts`); endpoint lama di server
dibiarkan utuh agar tidak merusak apa pun, hanya tidak dipakai lagi.

Duanya khusus form **Tim** & **Testimoni**: saat **Tambah baru** field urutan
**tidak ditampilkan** — item baru otomatis paling atas (server menggeser semua
baris lama +1, tidak ada yang dihapus). Testimoni baru langsung jadi **#1** di
slider beranda (beranda selalu tampil tepat 3; yang lama turun urutan dan tetap
tersimpan, bisa diubah lewat admin). Urutan manual tetap bisa diatur saat
**Ubah**. Tombol **Keluar** kini bergaris merah mencolok dan menampilkan
konfirmasi "Yakin keluar dari dashboard admin?".

Yang sengaja TIDAK dikelola CMS: **klien** (section Our Client dikomentari,
keputusan rapat) & konten statis di atas.

Field **Kategori** (form dokumentasi) kini berupa **dropdown opsi umum** —
Workshop, Kunjungan, Demo (`OPSI_KATEGORI` di `src/pages/Admin.tsx`) — plus
pilihan **"Lainnya (ketik sendiri)"** yang membuka input teks (maks 100
karakter, sejajar server). Kategori custom lama tetap tampil di input saat
diedit, jadi daftar pilihan tidak menumpuk dan tidak ambigu; menambah kategori
umum cukup satu entri di `OPSI_KATEGORI`.

Form **Kursus** juga berubah: **Target peserta** kini berupa **dropdown 1
pilihan** dari 4 label katalog (Mahasiswa, Dosen, Guru, Masyarakat umum) —
label selalu persis sama dengan filter katalog publik (dulu salah ketik membuat
kursus tidak muncul di filter mana pun), dan **Kode dibuat otomatis** dari
peserta terpilih + nomor berikutnya (prefiks M/D/G/U, `src/lib/kodeKursus.ts`):
Mahasiswa → M01, Guru → G01. Kode read-only saat tambah dan tetap terkunci saat
edit; kode lama (R01/E01/P01) berprefiks lain sehingga tidak ikut menaikkan
nomor. Kursus lama yang targetnya lebih dari satu tinggal pilih salah satunya
(catatan "Data lama punya N target …" mengingatkan bahwa simpan hanya
menyimpan pilihan itu) — Simpan tanpa target peserta ditolak dengan pesan
eksplisit.

Catatan hero (kini statis di `src/data/hero.ts`, tanpa tab admin): varian `srcSet`
harus menunjuk file yang benar-benar ada (kalau tidak, slide tetap menampilkan
gambar lama), dan slide tidak boleh dikosongkan (hero beranda jadi kosong).

## Ringkasan pengerjaan

1. Scaffold Vite React-TS + Tailwind + motion + Vitest + router; desain diadaptasi dari rapat sebelumnya.
2. Komponen reusable: layout header/footer (logo Ubaya → AI Center, dropdown Konten), hero carousel + client carousel otomatis (dots, jeda saat hover/fokus, hormat reduced-motion), slider testimoni, card berita/dokumentasi/tim dengan slot gambar.
3. Data dummy bertanda backend untuk hero, berita, dokumentasi, tim, klien, testimoni.
4. Optimasi Lighthouse hingga desktop 100/100/100/100 dan mobile 95/100/100/100 (robots.txt, dimensi gambar, target sentuh, kompresi + WebP responsif, code-splitting route, preload LCP).
5. Keputusan rapat 16 Sept: layanan tinggal 2 (Pelatihan + Inference Solution), Our Client dikomentari (kode dipertahankan), testimoni naik ke posisi Our Client dengan background `bg-soft`, kontak footer/Tentang Kami disentralisasi di `src/data/kontak.ts` (email `aicenter@unit.ubaya.ac.id`, WA 0895-6342-22240, website LPPM).
6. Unit test: frontend **238 test / 30 file** (lib, data, komponen, halaman, routing); backend **86 test**. `tsc` bersih di dua sisi.
7. Integrasi frontend↔backend: tabel + route `GET /api/kursus` (+ migrasi `0001`), lapisan `src/lib/api.ts` + hook `useApiData`, wiring semua halaman konten; seed disinkronkan dengan data frontend (tim 6 anggota, teks layanan, gambar hero).
8. Prioritas 2 (CRUD profil & tim, batas panjang field, pembersih gambar tidak terpakai) lalu konten halaman **Inference** pindah ke CMS: tabel `inference` (+ migrasi `0003`), `GET`/`PUT /api/inference`, tab Inference di `/admin`, dan `LayananDetail` memakai `useApiObjek('/inference', …)`.
9. Lengkapi CRUD admin: **testimoni** & **slide hero** (`POST`/`PUT`/`DELETE /api/testimoni[/:id]` dan `/api/hero-slides[/:id]`, tab Testimoni & Hero di `/admin`) — `id` & `urutan` ikut kontrak respons `GET`-nya, lalu `referensiGambar` juga membaca `image`/`srcSet` hero supaya pembersih gambar tidak terpakai tidak menghapus varian slide. Istilah "gambar yatim" diganti jadi **"gambar tidak terpakai"** (UI, kode: `lib/orphanUpload.ts` + `findOrphanUploads`, dan README). Gerbang saat ini: frontend **381 test / 36 file**, backend **221 test / 14 file**, `tsc` bersih di dua sisi + build produksi OK.
10. Audit backend terhadap 10 aturan kerja (`docs/prompt-persiapan-opencode.md`) — semua
    terpenuhi kecuali dua keputusan sadar yang dicatat di README ini: file test
    ikut repo, dan `drizzle.ts` tanpa unit test. Lalu putaran persiapan final:
    `UPLOAD_DIR` didokumentasikan di `server/.env.example`, penanda
    `TODO_BACKEND` di `robots.txt` diganti catatan deploy (penanda hanya untuk
    bagian yang butuh backend), `VITE_SITE_URL` dijelaskan fungsinya, serta
    section **Deployment (produksi)** + checklist sebelum final di README.
11. Field **Kategori** form dokumentasi di `/admin` → **dropdown opsi umum**
    (Workshop/Kunjungan/Demo) + "Lainnya (ketik sendiri)" yang membuka input
    teks (maks 100, sejajar server) — mengganti input bebas yang membuat
    kategori menumpuk & ambigu; nilai custom lama tetap terbaca saat diedit
    (dropdown menunjuk "Lainnya"). Gerbang saat ini: frontend **384 test /
    36 file** (3 test baru di `Admin.test.tsx`), `tsc -b` bersih, build OK;
    backend 221 test / 14 file.
12. Form **Kursus**: target peserta jadi **dropdown 1 pilihan dari 4 label
    katalog** (sebelumnya teks bebas; respons lanjutan: dari centang kembali ke
    dropdown) + **kode auto generate** dari peserta terpilih
    (`lib/kodeKursus.ts`: prefiks M/D/G/U + nomor terbesar berikutnya,
    read-only saat tambah, terkunci saat edit), guard "Target peserta wajib
    dipilih (menentukan kode otomatis)" sebelum request, dan catatan "Data lama
    punya N target …" untuk kursus multi-target lama. Gerbang saat ini:
    frontend **393 test / 37 file** (5 test lib baru + 4 test admin),
    `tsc -b` bersih, build OK; backend 221 test / 14 file.
13. **Optimasi Lighthouse** pada build produksi: peta chunk ditaruh di
    `index.html` sebelum IIFE pemakainya (modulepreload kini jalan ±73 ms),
    semua rute di-lazy kecuali NotFound, dan CSS di-inline ke `<style>` oleh
    plugin `inlineCssBuild` → **mobile 93 / desktop 99** (audit Lighthouse CLI
    headless tanpa ekstensi; dev `:5173` tidak dipakai untuk audit).
14. **CRUD Layanan**: tab **Layanan** di `/admin` (form nama/tagline/deskripsi +
    editor daftar `fitur`, slug read-only) → `POST`/`PUT`/`DELETE
    /api/layanan[/:slug]` dengan guard token; kunci baris = `slug` hasil
    `slugDariJudul(nama)` (bentrok → 409; slug dipegang tetap saat edit),
    validasi `validasiLayanan` di `server/src/lib/tulis.ts` (1–15 item fitur,
    maks 300 karakter per item). Gerbang saat ini: frontend **396 test /
    37 file** (3 test admin baru), `tsc -b` bersih, build OK; backend **232
    test / 14 file** (11 test baru: `validasiLayanan` + rute layanan).
15. **Katalog kursus dirapikan ala Coursera**: kartu katalog
    (`/layanan/pelatihan`) disusun ulang (eyebrow "Ubaya AI Center · kode",
    judul, baris fakta "level · durasi · N modul · ±X jam", instruktur, satu
    CTA — klaim "Sertifikat" dihapus dari kartu); hero detail kursus dapat
    fakta **Estimasi belajar** dari helper baru `src/lib/kursus.ts`
    (`menitDariMeta`/`totalMenitKursus`/`labelDurasiTotal`, 10 unit test).
    Data asli yang perlu dikonfirmasi user dikumpulkan di
    **`docs/data-kursus.md`** (template isian level/format/instruktur/
    sertifikat/video/kuis + penanda `TODO_KONTEN` di `src/data/pelatihan.ts`).
16. **Sistem video & asesmen per modul**: field `modul` kini boleh memuat
    `video` (URL http(s) ≤ 300, divalidasi `bacaVideoModul`) dan `quiz`
    (≤ 10 soal × 2–6 opsi × 200 karakter, `kunci` = index opsi —
    `bacaKuisModul` di `server/src/lib/tulis.ts`; baris lama tanpa field ini
    tetap valid → dinormalkan `null`/`[]`). Tab **Kursus** di `/admin` punya
    input URL video + editor soal (radio jawaban benar, +/− opsi, buang soal
    kosong saat kirim via `kuisSiapKirim`). Ruang belajar (`LearningWorkspace`)
    meng-embed YouTube/Vimeo mode nocookie (`src/lib/video.ts`, URL lain →
    tautan luar), dan checkpoint memakai kuis nyata bila tersedia (lulus =
    semua soal benar → `lulusQuiz`); tanpa data → perilaku lama (blok
    "video menyusul" + checkpoint dummy). Gerbang saat ini: frontend **416
    test / 39 file**, `tsc -b` bersih, build OK; backend **238 test / 14
    file** (6 test baru: validasi video/kuis + rute kursus).
17. **Audit pre-final** (10 Okt 2026) terhadap 10 aturan kerja + kesiapan
    deploy: pindai rahasia (`.env` ter-ignore, `.env.example` dummy semua),
    penanda TODO tiap butir ber-alasan, nol referensi WordPress (komentar
    "plugin WordPress" di `pelatihan.ts` diparafrase & typo nomor WA di
    `kontak.ts` dibetulkan `6289563422240`), semua tautan internal + anchor
    (`#layanan`/`#kontak`) cocok dengan peta rute `App.tsx` (skrip audit
    lokal), angka test basi di README diperbarui (53 file). Verifikasi:
    smoke API **36/36**, smoke halaman **11/11** (h1 benar, konsol 0
    error/warning), health `{"status":"ok","db":"ok"}`, gerbang ulang FE
    **416/416** + BE **238/238**, dan **Lighthouse mobile 93 / desktop 100**
    (a11y, best-practices, SEO 100 di dua mode; TBT mobile 30 ms) terhadap
    build produksi — arsip `lighthouse_report/prod-2026-10-10-*.json`
    (lokal/gitignored).
18. **Refactor admin + urutan otomatis** (15 Okt 2026): 4 tab **Layanan/
    Profil/Inference/Hero dihapus** — halaman publiknya tetap, kontennya jadi
    statis frontend (`src/data/{hero,layanan,profil,inference}.ts`); endpoint
    lama di server dibiarkan utuh (tak dipakai FE). Backend: `naikkanSemuaUrutan()`
    (`server/src/repositories/`) dipanggil sebelum `POST /api/tim` &
    `/api/testimoni` → semua baris lama digeser +1 lalu item baru disimpan
    `urutan: 0` (testimoni baru = #1 beranda, lama turun; tidak ada yang
    dihapus). Form admin: field urutan disembunyikan saat **Tambah** (tetap ada
    saat **Ubah**); beranda membatasi `slice(0, 3)` testimoni; tombol **Keluar**
    bergaris merah + `window.confirm("Yakin keluar dari dashboard admin?")`.
    Gerbang saat ini: frontend **406 test / 39 file** (`tsc -b` bersih, build
    OK), backend **238 test / 14 file**.
19. **Geist Mono bobot nyata + Lighthouse ulang** (15 Okt 2026): screenshot
    spesifikasi Figma dicek ulang — palet Nuansa Biru (6 primer + 4
    pelengkap) & font (Cabinet Grotesk judul / General Sans isi /
    Geist Mono teknis + fallback Helvetica) sudah cocok 100% dengan token
    `src/index.css`. Satu celah ditemukan: `public/fonts/GeistMono-Regular.woff2`
    statis bobot 400, padahal kicker/tag memakai `font-mono font-bold` (5
    tempat) → bold sintesis browser. Diganti **file variabel resmi Google
    Fonts** (OFL, subset latin, `GeistMono-Variable.woff2`, sumbu 100–900,
    `font-weight: 100 900`) → bold sungguhan (diverifikasi: cetak 400 ≠ 700
    via canvas, `document.fonts.check('700 …')` true). Test baru: rentang
    bobot mono + seluruh `url('/fonts/*.woff2')` di CSS wajib ada di disk.
    Gerbang: FE **408/408**, BE **238/238**, `tsc` bersih; **Lighthouse
    ulang** terhadap build hasil refactor: **mobile 92 / desktop 99**
    (a11y, best-practices, SEO 100/100 di dua mode; TBT mobile 30 ms) —
    arsip `lighthouse_report/prod-2026-10-15-*.json` (lokal/gitignored).
20. **Progres LMS tersimpan di backend tanpa akun** (15 Okt 2026): menutup
    `TODO_BACKEND` progress per peserta tanpa menunggu keputusan akun —
    tabel `progress_pembelajaran` (PK gabungan `peserta_id` + `kode`, migrasi
    `0004`), repository + mapper `toProgresPeserta`, dua endpoint **publik**:
    `GET /api/progress?pesertaId=&kode=` (filter ketat 8–64 `[A-Za-z0-9-]`,
    kode uppercase) dan `POST /api/progress` (UPSERT per peserta+kursus,
    `state` objek ≤ 32 KB, rate-limit **60 tulis/menit/IP** → 429 +
    `Retry-After`). Identitas peserta = `pesertaId` acak per-browser
    (`src/lib/progresPeserta.ts`); localStorage tetap sumber utama (offline),
    backend = salinan cadangan; saat keduanya ada → **progres lebih tinggi
    menang, seri → jejak belajar lebih banyak, seri penuh → lokal**
    (`gabungStateBelajar` + `jejakStateBelajar`), dan state kosong tidak
    dikirim (`stateBelajarTerisi`) supaya tak ada baris percuma. Semua
    kegagalan sinkron disenyapkan (konsol tetap bersih). TODO inference
    diklarifikasi: `/api/inference` = CMS konten halaman, bukan prediktor —
    output nyata tetap menunggu keputusan model. Gerbang: **FE 424 test /
    40 file**, **BE 255 test**, `tsc` bersih dua sisi, build OK; uji langsung
    API (create → get → upsert 1 baris → 400 untuk input invalid) & migrasi
    `0004` terpasang di DB dev. E2E browser: enroll → POST 200 (kode
    uppercase), hapus state lokal → reload → ruang belajar **pulih dari
    server**, aksi lesson → POST 200, konsol 0 error/warning. Lighthouse
    ulang: **mobile 91 / desktop 99** (a11y/BP/SEO 100/100, CLS 0).

21. **PROGRESS 4 — status permintaan user + warna situs disentralisasi ke
    token** (17 Okt 2026): audit tiga poin briefing terhadap kode.
    (a) Layanan/Profil/Inference/Hero "dihapus, nanti diedit via front" —
    **sudah** sejak refactor admin: 5 tab tersisa (Dokumentasi, Berita,
    Kursus, Tim, Testimoni), konten keempat bagian statis di `src/data/*`.
    (b) Prinsip "tambah baru tidak menambah jumlah tampilan" — **sudah**:
    testimoni slider tampil tepat 3 (counter `1 / 3`; item baru via admin
    otomatis #1, lama turun, tak dihapus), dokumentasi & berita di beranda
    selalu `slice(0, 3)` terbaru (urut tanggal desc; form admin default
    tanggal hari ini) — dikunci test (baris "testimoni tampil tepat 3",
    "highlight membatasi 3 card", "dokumentasi 3 terbaru").
    (c) Font & palet Figma — font + 10 warna daftar sudah 100% (butir 19);
    celah terakhir = 14 hex hardcoded di 6 file komponen. Dipindahkan ke
    token `@theme` tanpa mengubah tampilan: 3 hex = nilai persis token
    (gradien beranda kini `var(--color-navy/-sky/-soft)`), 5 hex turunan
    navy dideklarasikan (`--color-onnavy`, `-badge`, `-body`, `-soft`,
    `-dim`; nilai persis hex lama). Test baru: nilai tiap turunan persis
    + kontras ≥4.5:1 vs navy + **skener nol hex hardcoded** di seluruh
    `src/**/*.{ts,tsx}` (semua warna wajib lewat token). Gerbang: **FE 427
    test / 40 file**, **BE 255 test**, `tsc` bersih dua sisi, build OK;
    E2E beranda: keempat utilitas token warna terbaca persis di devtools,
    gradien `var()` ter-render, counter testimoni `1 / 3`, konsol 0
    error/warning. **Lighthouse ulang** (URL `/beranda`, metode sama dengan
    15 Okt): **mobile 90 / desktop 99** (a11y, best-practices, SEO
    100/100 di dua mode) — arsip
    `lighthouse_report/prod-2026-10-17-*.json` (lokal/gitignored).

22. **UX ruang belajar diperjelas (permintaan user setelah uji coba)**
    (17 Okt 2026): user bingung saat "Mulai modul" tidak bereaksi dan label
    "Lesson sudah ditonton" terlihat seperti tombol aktif. Tiga perbaikan
    (nilai/aturan belajar tidak berubah — hanya kejelasan):
    (a) kartu terkunci kini menjelaskan alasannya: "Tonton lesson + lulus
    checkpoint modul sebelumnya untuk membuka kunci." (3 kartu terkunci);
    (b) klik "Mulai modul"/"Ulangi" auto-scroll ke panel lesson
    (`#panel-lesson`; dulu panel terbuka diam-diam di bawah kartu);
    (c) setelah lesson ditonton, tombol berubah jadi penanda ✓ non-klik
    "Lesson ditonton" + pengarah "Selanjutnya: kerjakan checkpoint di bawah
    untuk menyelesaikan modul." (kunci i18n lama 'Lesson sudah ditonton'
    diganti; kamus ID→EN ikut diperbarui). Test baru: hint terkunci ×3,
    auto-scroll `Mulai modul` (spy `scrollIntoView`), status ✓ non-klik +
    pengarah. Gerbang: **FE 429 test / 40 file**, `tsc` bersih, build OK.
    E2E (state dibersihkan dulu — localStorage + baris cadangan backend
    di-overwrite state kosong): enroll → scroll ke ruang belajar → hint
    terkunci tampil 3× → "Mulai modul" → panel lesson pindah ke posisi
    atas layar (scrollY 1801 → 2561) → "Mulai lesson" → badge ✓ muncul,
    tombol aktif hilang, watched tersimpan → konsol 0 error/warning.

### Penanda TODO

- `TODO_BACKEND` — bagian yang sengaja belum diintegrasikan + alasannya (lihat "Status integrasi frontend").
- `TODO_ASSET` — file aset perlu diganti/ditambah di `public/`.
- `TODO_KONTEN` — teks menyusul dari dokumen resmi (mis. visi/misi dari PDF rapat 16 Sept 2026); untuk kursus: template isian data asli (level, instruktur, sertifikat, URL video + kuis per modul) ada di `docs/data-kursus.md`.
